#!/usr/bin/env bash
# Avni AI — offline asset fetcher.
# Downloads ONLY open-source, freely licensed assets into app/src/main/assets/.
# At runtime the app never touches the network except the optional GGUF
# model download inside ModelManager (same URLs, resumable, user-triggered).
# Usage: bash scripts/fetch-assets.sh
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
A="$ROOT/app/src/main/assets"
mkdir -p "$A/js" "$A/models/vosk" "$A/models/llm" "$A/avatar"

echo "== Three.js (MIT) + @pixiv/three-vrm (MIT) =="
# Pinned versions; these files are bundled into assets/ and served locally.
curl -L -o "$A/js/three.module.min.js" \
  https://cdn.jsdelivr.net/npm/three@0.160.0/build/three.module.min.js
curl -L -o "$A/js/three-vrm.module.min.js" \
  https://cdn.jsdelivr.net/npm/@pixiv/three-vrm@3.1.0/lib/three-vrm.module.min.js
mkdir -p "$A/js/examples/jsm/loaders"
curl -L -o "$A/js/examples/jsm/loaders/GLTFLoader.js" \
  https://cdn.jsdelivr.net/npm/three@0.160.0/examples/jsm/loaders/GLTFLoader.js

echo "== Vosk small models (Apache-2.0) =="
curl -L -o /tmp/vosk-hi.zip \
  https://alphacephei.com/vosk/models/vosk-model-small-hi-0.22.zip
curl -L -o /tmp/vosk-en.zip \
  https://alphacephei.com/vosk/models/vosk-model-small-en-us-0.15.zip
unzip -o -q /tmp/vosk-hi.zip -d /tmp/vosk-hi
unzip -o -q /tmp/vosk-en.zip -d /tmp/vosk-en
cp -r /tmp/vosk-hi/vosk-model-small-hi-0.22 "$A/models/vosk/hi"
cp -r /tmp/vosk-en/vosk-model-small-en-us-0.15 "$A/models/vosk/en"

echo "== Qwen2.5 1.5B Instruct Q4_K_M GGUF (Apache-2.0) =="
# ~1 GB. Skip with SKIP_LLM=1 if you will import a local .gguf instead.
if [ "${SKIP_LLM:-0}" != "1" ]; then
  curl -L -o "$A/models/llm/qwen2.5-1.5b-instruct-q4_k_m.gguf" \
    https://huggingface.co/Qwen/Qwen2.5-1.5B-Instruct-GGUF/resolve/main/qwen2.5-1.5b-instruct-q4_k_m.gguf
fi

echo "== Default VRM avatar (VRoid Hub free model) =="
echo "Download any free VRM from https://hub.vroid.com/ and place it at:"
echo "  $A/avatar/default.vrm"
echo "The app ships a procedural fallback avatar (built in avatar.js) if no .vrm is present."

echo "== llama.cpp (MIT) for the JNI engine =="
if [ ! -d "$ROOT/app/src/main/cpp/llama.cpp" ]; then
  git clone --depth 1 --branch b3527 \
    https://github.com/ggerganov/llama.cpp.git "$ROOT/app/src/main/cpp/llama.cpp"
fi
echo "Done. See README.md for build steps."
