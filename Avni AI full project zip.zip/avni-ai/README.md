# Avni AI — Fully Offline Jarvis-style Voice Assistant (Android)

**Kotlin + Jetpack Compose + MVVM + Hilt + Room (SQLCipher) + DataStore.**
**3D anime avatar:** Three.js + @pixiv/three-vrm, bundled in `assets/`, rendered in a
WebView — fully offline, no CDN at runtime.
**Brain:** on-device Qwen2.5 1.5B Instruct (GGUF Q4) via llama.cpp JNI, with a
MediaPipe LLM Inference fallback and a rule-based chat fallback.
**Voice:** Vosk offline STT (Hindi + English), Android TTS, offline "Hey Avni"
wake word via Vosk grammar mode.
**Zero budget:** no paid APIs, no cloud, no API keys, no analytics. The only
network use is the optional, user-triggered model download.

## 1. Build & run

```bash
# 1) Fetch offline assets (Three.js, Vosk models, llama.cpp; LLM optional)
bash scripts/fetch-assets.sh
#    SKIP_LLM=1 bash scripts/fetch-assets.sh   # if you import a local .gguf

# 2) Put a free VRM model (optional — procedural fallback exists) at:
#    app/src/main/assets/avatar/default.vrm   (VRoid Hub free models)

# 3) Open in Android Studio (Hedgehog+) and Run on a physical device
#    (emulator works for UI, but mic + TTS + Vosk need a real phone).
#    Or from the command line:
./gradlew :app:assembleDebug
adb install -r app/build/outputs/apk/debug/app-debug.apk
```

Requirements: Android Studio Hedgehog+, JDK 17, Android SDK 34, NDK 25+ with
CMake 3.22. minSdk 26, targetSdk 34.

## 2. First run (on the phone)

1. **Onboarding** explains every permission in Hinglish — grant Mic, then
   Contacts/Notifications/Accessibility/Overlay only if you want those features.
2. **Model Manager** (Settings → Model): download Qwen2.5 1.5B Q4 (~1 GB,
   resumable, progress shown) or **Import local .gguf** from storage.
   Until a model loads, Avni answers with the offline rule-based chat engine
   (commands, facts, memory all still work).
3. **Vosk models** ship in assets (Hindi + English small). First launch copies
   them to internal storage; no download needed.
4. Say **"Hey Avni"** or tap the mic. Try: *"Hey Avni, torch on karo"*,
   *"Rahul ko call karo"*, *"Good morning"* (routine), *"Mera naam Madhur hai,
   yaad rakho"*.

## 3. Milestones (all complete in this tree)

1. **Voice loop + LLM** — `voice/`, `llm/`: Vosk STT, TTS with viseme
   driving, wake word, llama.cpp JNI, ModelManager (download/resume/import),
   strict JSON action schema with retry + chat fallback.
2. **Phone control** — `intent/`, `service/`: intents, direct APIs
   (torch/volume/brightness/DND/panels/battery/clipboard/media), Accessibility
   (read/tap/swipe/type/click-by-text), NotificationListener (read + voice
   reply), contacts fuzzy match, routines/macros, safety confirmations,
   banking/UPI blocklist, action log.
3. **3D avatar + lip-sync** — `assets/avatar/`, `avatar/`: VRM loader
   (bundled + user .vrm import), idle/breath/blink, head-eye tracking,
   8 states, emotion tags, visemes from TTS, sci-fi HUD, camera modes,
   low-power mode, overlay bubble.
4. **Overlay / assistant / routines** — foreground service, boot autostart
   option, Quick Settings tile, home widget, ACTION_ASSIST /
   VoiceInteractionService, onboarding.
5. **Polish** — all screens, dark Jarvis theme, Hindi+English strings,
   encrypted DB, low-RAM mode, model unload on idle, thermal check,
   "delete all data" button.

## 4. Test checklist

- [ ] Onboarding: each permission explains itself; skipping still opens Main.
- [ ] "Hey Avni" wakes from background (service notification visible).
- [ ] Tap mic → speak Hindi → transcript appears → Avni replies in Hinglish.
- [ ] "Torch on karo" / "Torch band karo" toggles flashlight; action log entry.
- [ ] "Rahul ko call karo" asks voice confirmation before dialing.
- [ ] "WhatsApp pe Rahul ko hi bhejo" opens WhatsApp via Accessibility tap.
- [ ] "Good morning" runs the routine chain (battery + calendar + summary).
- [ ] Avatar: idle breathing, blinking, speaking lip-sync, [happy] wave.
- [ ] Settings → Model: download shows progress, pause/resume works, import works.
- [ ] Low-RAM mode + model unload on idle; thermal state shown in Diagnostics.
- [ ] Settings → Privacy → Delete all data wipes Room + DataStore + logs.
- [ ] Overlay bubble appears over another app (after granting overlay).
- [ ] QS tile toggles listening; widget tap opens Main.
- [ ] Long-press assistant (default assistant set) opens Avni.

## 5. Honest limitations (no fake capabilities)

- On-device 1.5B LLM is slower and weaker than cloud models; long answers
  are capped and streamed. Rule-based chat covers commands even without a model.
- Vosk small models mis-hear names sometimes — contacts use fuzzy matching
  and confirm before calling/messaging.
- Accessibility control needs the user to enable it in Settings; Avni never
  bypasses lock screens, reads passwords, or touches banking/UPI apps
  (blocklisted unless explicitly enabled).
- MediaPipe LLM fallback needs its own `.task` model file if you choose it.
- VRM quality depends on the model file; the procedural fallback avatar has
  no VRM bones but keeps all states/HUD working.
