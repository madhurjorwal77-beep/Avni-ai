// Avni avatar — fully offline. Loads three.js + three-vrm from assets/js
// (bundled by scripts/fetch-assets.sh; never a CDN at runtime).
// Exposes window.AvniAvatar for the Kotlin bridge:
//   setState('listening'|'thinking'|'speaking'|'happy'|'sad'|'surprised'|'angry'|'sleeping'|'idle')
//   setViseme('aa'|'ih'|'ou'|'ee'|'oh', value 0..1)
//   setCamera('full'|'bust'|'closeup'), setLowPower(bool), setWaveform(level 0..1)
//   loadVrm(url)  — user .vrm file (file:// or content served by WebView)
//   gesture('wave'|'nod'|'shake'|'bow'), setHairColor('#rrggbb')
import * as THREE from 'three';
import { GLTFLoader } from 'three/addons/loaders/GLTFLoader.js';
import { VRMLoaderPlugin, VRMUtils } from '@pixiv/three-vrm';

const scene = new THREE.Scene();
scene.background = new THREE.Color(0x050a14);
const camera = new THREE.PerspectiveCamera(30, innerWidth / innerHeight, 0.1, 20);
const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: false });
renderer.setSize(innerWidth, innerHeight);
renderer.setPixelRatio(Math.min(devicePixelRatio, 2));
renderer.outputColorSpace = THREE.SRGBColorSpace;
document.getElementById('scene').appendChild(renderer.domElement);

// Lights
scene.add(new THREE.AmbientLight(0xffffff, 0.9));
const key = new THREE.DirectionalLight(0x00e5ff, 1.4); key.position.set(2, 3, 4); scene.add(key);
const rim = new THREE.DirectionalLight(0x7c4dff, 1.0); rim.position.set(-3, 2, -2); scene.add(rim);

// ---------- Fallback procedural avatar (used when no .vrm is present) ----------
const fallback = new THREE.Group();
{
  const skin = new THREE.MeshStandardMaterial({ color: 0xffd9b8, roughness: 0.7 });
  const hair = new THREE.MeshStandardMaterial({ color: 0x1a2333, roughness: 0.5 });
  const dress = new THREE.MeshStandardMaterial({ color: 0x00bcd4, roughness: 0.4, emissive: 0x004455 });
  const head = new THREE.Mesh(new THREE.SphereGeometry(0.32, 32, 32), skin);
  head.position.y = 1.55; fallback.add(head);
  const hairTop = new THREE.Mesh(new THREE.SphereGeometry(0.35, 32, 32, 0, Math.PI * 2, 0, Math.PI * 0.55), hair);
  hairTop.position.y = 1.62; fallback.add(hairTop);
  const eyeMat = new THREE.MeshBasicMaterial({ color: 0x0a1626 });
  const eyeL = new THREE.Mesh(new THREE.SphereGeometry(0.035, 16, 16), eyeMat);
  eyeL.position.set(-0.12, 1.56, 0.29); fallback.add(eyeL);
  const eyeR = eyeL.clone(); eyeR.position.x = 0.12; fallback.add(eyeR);
  const body = new THREE.Mesh(new THREE.CylinderGeometry(0.22, 0.34, 0.9, 24), dress);
  body.position.y = 0.75; fallback.add(body);
  const mouth = new THREE.Mesh(new THREE.SphereGeometry(0.05, 16, 16), new THREE.MeshBasicMaterial({ color: 0x662233 }));
  mouth.position.set(0, 1.42, 0.30); mouth.scale.set(1, 0.4, 0.5); fallback.add(mouth);
  fallback.userData = { head, eyeL, eyeR, mouth, hair: hairTop };
}
scene.add(fallback);

// ---------- VRM ----------
let vrm = null, vrmHead = null, vrmEyes = null;
async function loadVrm(url) {
  try {
    const loader = new GLTFLoader();
    loader.register(p => new VRMLoaderPlugin(p));
    const gltf = await loader.loadAsync(url);
    const next = gltf.userData.vrm;
    VRMUtils.removeUnnecessaryVertices(gltf.scene);
    VRMUtils.removeUnnecessaryJoints(gltf.scene);
    if (vrm) scene.remove(vrm.scene);
    vrm = next; scene.add(vrm.scene);
    fallback.visible = false;
    vrmHead = vrm.humanoid.getNormalizedBoneNode('head');
    vrm.scene.rotation.y = Math.PI;
    if (window.AvniBridge) window.AvniBridge.onVrmLoaded('ok');
  } catch (e) {
    fallback.visible = true;
    if (window.AvniBridge) window.AvniBridge.onVrmLoaded('fail:' + e.message);
  }
}
// Default bundled model, if present (WebView serves assets via loadUrl).
loadVrm('default.vrm');

// ---------- State, expressions, visemes ----------
let state = 'idle';
let viseme = { name: 'aa', value: 0 };
let gestureUntil = 0, gestureKind = '';
let blinkAt = performance.now() + 2500, blinkPhase = 0;
let lookX = 0, lookY = 0, targetLookX = 0, targetLookY = 0;
let camMode = 'bust', camDist = 2.6, camTarget = 1.1;
let lowPower = false, waveLevel = 0, glowRing = 0;

function setExpr(name, v) {
  if (vrm && vrm.expressionManager) vrm.expressionManager.setValue(name, v);
}
function applyState() {
  const happy = state === 'happy' ? 1 : 0;
  const sad = state === 'sad' ? 1 : 0;
  const surprised = state === 'surprised' ? 1 : 0;
  const angry = state === 'angry' ? 1 : 0;
  setExpr('happy', happy); setExpr('sad', sad);
  setExpr('surprised', surprised); setExpr('angry', angry);
  setExpr('relaxed', state === 'idle' || state === 'sleeping' ? 0.6 : 0);
  glowRing = state === 'listening' ? 1 : 0;
}

// Pointer / gyro head-eye tracking
addEventListener('pointermove', e => {
  targetLookX = (e.clientX / innerWidth - 0.5) * 0.6;
  targetLookY = -(e.clientY / innerHeight - 0.5) * 0.4;
});
addEventListener('deviceorientation', e => {
  if (e.gamma != null) targetLookX = THREE.MathUtils.clamp(e.gamma / 45, -0.5, 0.5);
  if (e.beta != null) targetLookY = THREE.MathUtils.clamp((e.beta - 45) / 45, -0.4, 0.4);
});

// Pinch zoom / drag rotate
let lastDist = 0, rotY = Math.PI;
renderer.domElement.addEventListener('touchstart', e => {
  if (e.touches.length === 2) lastDist = Math.hypot(
    e.touches[0].clientX - e.touches[1].clientX,
    e.touches[0].clientY - e.touches[1].clientY);
}, { passive: true });
renderer.domElement.addEventListener('touchmove', e => {
  if (e.touches.length === 2) {
    const d = Math.hypot(e.touches[0].clientX - e.touches[1].clientX,
      e.touches[0].clientY - e.touches[1].clientY);
    if (lastDist > 0) camDist = THREE.MathUtils.clamp(camDist * lastDist / d, 1.2, 5);
    lastDist = d;
  } else if (e.touches.length === 1) {
    rotY += e.touches[0].clientX / innerWidth * 0.01;
  }
}, { passive: true });

// ---------- HUD: rings + particles + waveform ----------
const hud = document.getElementById('hud');
const hctx = hud.getContext('2d');
const wave = document.getElementById('wave');
const wctx = wave.getContext('2d');
function resizeHud() {
  hud.width = innerWidth; hud.height = innerHeight;
  wave.width = innerWidth; wave.height = 90;
}
addEventListener('resize', () => {
  camera.aspect = innerWidth / innerHeight; camera.updateProjectionMatrix();
  renderer.setSize(innerWidth, innerHeight); resizeHud();
});
resizeHud();
const particles = Array.from({ length: lowPower ? 40 : 140 }, () => ({
  x: Math.random(), y: Math.random(), s: Math.random() * 2 + 0.5, v: Math.random() * 0.0004 + 0.0001
}));
function drawHud(t) {
  hctx.clearRect(0, 0, hud.width, hud.height);
  const cx = hud.width / 2, cy = hud.height * 0.42, base = Math.min(hud.width, hud.height);
  // Glow ring while listening
  if (glowRing > 0.05) {
    hctx.beginPath();
    hctx.arc(cx, cy, base * 0.34 + Math.sin(t * 0.004) * 6, 0, Math.PI * 2);
    hctx.strokeStyle = `rgba(0,229,255,${0.7 * glowRing})`;
    hctx.lineWidth = 3; hctx.stroke();
  }
  for (const ring of [0.30, 0.36, 0.42]) {
    hctx.beginPath();
    hctx.arc(cx, cy, base * ring, 0, Math.PI * 2);
    hctx.strokeStyle = 'rgba(0,229,255,0.18)'; hctx.lineWidth = 1; hctx.stroke();
  }
  hctx.fillStyle = 'rgba(0,229,255,0.7)';
  for (const p of particles) {
    p.y -= p.v; if (p.y < 0) p.y = 1;
    hctx.beginPath(); hctx.arc(p.x * hud.width, p.y * hud.height, p.s, 0, Math.PI * 2); hctx.fill();
  }
  // Waveform bar at bottom
  wctx.clearRect(0, 0, wave.width, wave.height);
  const speaking = state === 'speaking';
  const amp = speaking ? 0.4 + waveLevel * 0.6 : 0.08;
  wctx.strokeStyle = '#00e5ff'; wctx.lineWidth = 2;
  wctx.beginPath();
  for (let x = 0; x < wave.width; x += 6) {
    const y = wave.height / 2 + Math.sin(x * 0.05 + t * 0.01) * amp * 28 * Math.sin(x * 0.01);
    x === 0 ? wctx.moveTo(x, y) : wctx.lineTo(x, y);
  }
  wctx.stroke();
}

// ---------- Animation loop ----------
let lastT = performance.now(), acc = 0;
function animate(now) {
  requestAnimationFrame(animate);
  if (lowPower) { acc += now - lastT; lastT = now; if (acc < 33) return; acc = 0; }
  else lastT = now;
  const t = now / 1000;
  lookX += (targetLookX - lookX) * 0.08;
  lookY += (targetLookY - lookY) * 0.08;

  // Breathing + idle sway
  const breathe = Math.sin(t * 1.6) * 0.02;
  const sway = Math.sin(t * 0.8) * 0.03;
  if (vrm) {
    vrm.update(now / 1000);
    const chest = vrm.humanoid.getNormalizedBoneNode('chest');
    if (chest) chest.position.y = breathe;
    if (vrmHead) {
      vrmHead.rotation.y = lookX + sway;
      vrmHead.rotation.x = lookY + (state === 'thinking' ? -0.35 : 0);
      if (state === 'listening') vrmHead.rotation.x += 0.15; // leans in
    }
    // Blink
    if (now > blinkAt) { blinkPhase = 1; blinkAt = now + 2200 + Math.random() * 2500; }
    if (blinkPhase > 0) {
      setExpr('blink', Math.min(1, blinkPhase * 2));
      blinkPhase -= 0.12;
      if (blinkPhase <= 0) setExpr('blink', 0);
    }
    // Visemes
    for (const v of ['aa', 'ih', 'ou', 'ee', 'oh']) setExpr(v, 0);
    if (state === 'speaking' && viseme.value > 0) setExpr(viseme.name, viseme.value);
    // Gestures
    const armR = vrm.humanoid.getNormalizedBoneNode('rightUpperArm');
    if (armR) {
      if (gestureKind === 'wave' && now < gestureUntil) armR.rotation.z = -2.2 + Math.sin(t * 10) * 0.3;
      else if (gestureKind === 'bow' && now < gestureUntil) { if (vrmHead) vrmHead.rotation.x = 0.5; }
      else armR.rotation.z = -0.15;
    }
    if (vrmHead && gestureKind === 'nod' && now < gestureUntil) vrmHead.rotation.x = Math.abs(Math.sin(t * 8)) * 0.3;
    if (vrmHead && gestureKind === 'shake' && now < gestureUntil) vrmHead.rotation.y = Math.sin(t * 10) * 0.3;
  } else {
    // Fallback figure animation
    const u = fallback.userData;
    fallback.position.y = breathe;
    u.head.rotation.y = lookX + sway;
    u.head.rotation.x = lookY + (state === 'thinking' ? -0.35 : 0);
    if (now > blinkAt) { blinkPhase = 1; blinkAt = now + 2200 + Math.random() * 2500; }
    if (blinkPhase > 0) {
      u.eyeL.scale.y = u.eyeR.scale.y = Math.max(0.1, 1 - blinkPhase * 2);
      blinkPhase -= 0.12;
    } else { u.eyeL.scale.y = u.eyeR.scale.y = 1; }
    const mouthOpen = state === 'speaking' ? 0.4 + viseme.value * 0.8 : 0.4;
    u.mouth.scale.y = mouthOpen;
    if (gestureKind === 'wave' && now < gestureUntil) fallback.rotation.y = Math.sin(t * 10) * 0.1;
  }

  // Camera modes
  const dist = camMode === 'full' ? 3.6 : camMode === 'closeup' ? 1.7 : camDist;
  const ty = camMode === 'full' ? 0.9 : camMode === 'closeup' ? 1.5 : camTarget;
  camera.position.set(Math.sin(rotY) * 0.0, ty + 0.4, dist);
  camera.lookAt(0, ty, 0);

  drawHud(now);
  renderer.render(scene, camera);
}
requestAnimationFrame(animate);

// ---------- Kotlin bridge ----------
window.AvniAvatar = {
  setState(s) { state = s; applyState(); },
  setViseme(name, v) { viseme = { name, value: v }; waveLevel = v; },
  setCamera(m) { camMode = m; },
  setLowPower(b) { lowPower = b; },
  setWaveform(v) { waveLevel = v; },
  gesture(g) { gestureKind = g; gestureUntil = performance.now() + 1800; },
  setHairColor(hex) {
    if (vrm) {
      vrm.scene.traverse(o => {
        if (o.isMesh && o.material && o.material.name && o.material.name.toLowerCase().includes('hair'))
          o.material.color.set(hex);
      });
    } else fallback.userData.hair.material.color.set(hex);
  },
  loadVrm
};
