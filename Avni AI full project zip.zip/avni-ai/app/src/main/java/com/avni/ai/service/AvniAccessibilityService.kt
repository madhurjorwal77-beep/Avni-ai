package com.avni.ai.service

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.graphics.Rect
import android.os.Build
import android.view.Display
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import androidx.annotation.RequiresApi
import kotlinx.coroutines.*

/**
 * Operates any app on the user's spoken instruction: read screen text,
 * tap a control by its visible text, swipe, back/home. Only acts when
 * ActionExecutor asks it to (never on its own), and never reads password
 * fields (isPassword nodes are skipped in readScreen).
 */
class AvniAccessibilityService : AccessibilityService() {

    companion object {
        var instance: AvniAccessibilityService? = null
            private set
    }

    override fun onServiceConnected() { instance = this }
    override fun onDestroy() { if (instance == this) instance = null }
    override fun onAccessibilityEvent(event: AccessibilityEvent) {}
    override fun onInterrupt() {}

    /** Concatenated visible text of the current window (passwords excluded). */
    fun readScreen(): String {
        val root = rootInActiveWindow ?: return "Koi window nahi mili."
        val sb = StringBuilder()
        collectText(root, sb)
        val text = sb.toString().trim().take(1000)
        return if (text.isBlank()) "Screen par padhne layak text nahi mila." else text
    }

    private fun collectText(node: AccessibilityNodeInfo, sb: StringBuilder) {
        if (node.isPassword) return
        node.text?.let { if (it.isNotBlank()) sb.append(it).append(' ') }
        node.contentDescription?.let { if (it.isNotBlank()) sb.append(it).append(' ') }
        for (i in 0 until node.childCount) node.getChild(i)?.let { collectText(it, sb) }
    }

    /** Tap the first clickable node whose visible text matches (case-insensitive). */
    fun tapByText(text: String): Boolean {
        val root = rootInActiveWindow ?: return false
        val node = findByText(root, text.lowercase()) ?: return false
        return clickUp(node)
    }

    private fun findByText(node: AccessibilityNodeInfo, query: String): AccessibilityNodeInfo? {
        if ((node.text?.toString()?.lowercase()?.contains(query) == true ||
                node.contentDescription?.toString()?.lowercase()?.contains(query) == true)) {
            var n: AccessibilityNodeInfo? = node
            while (n != null && !n.isClickable) n = n.parent
            if (n != null) return n
        }
        for (i in 0 until node.childCount) {
            node.getChild(i)?.let { findByText(it, query)?.let { found -> return found } }
        }
        return null
    }

    private fun clickUp(node: AccessibilityNodeInfo): Boolean {
        if (node.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true
        val rect = Rect()
        node.getBoundsInScreen(rect)
        return tapAt(rect.centerX().toFloat(), rect.centerY().toFloat())
    }

    fun tapAt(x: Float, y: Float): Boolean {
        val path = Path().apply { moveTo(x, y) }
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, 80)).build()
        var ok = false
        val latch = java.util.concurrent.CountDownLatch(1)
        dispatchGesture(gesture, object : GestureResultCallback() {
            override fun onCompleted(g: GestureDescription) { ok = true; latch.countDown() }
            override fun onCancelled(g: GestureDescription) { latch.countDown() }
        }, null)
        latch.await(2, java.util.concurrent.TimeUnit.SECONDS)
        return ok
    }

    fun swipe(dir: String): Boolean {
        val metrics = resources.displayMetrics
        val w = metrics.widthPixels.toFloat()
        val h = metrics.heightPixels.toFloat()
        val (sx, sy, ex, ey) = when (dir.lowercase()) {
            "down" -> arrayOf(w / 2, h * 0.3f, w / 2, h * 0.7f)
            "left" -> arrayOf(w * 0.8f, h / 2, w * 0.2f, h / 2)
            "right" -> arrayOf(w * 0.2f, h / 2, w * 0.8f, h / 2)
            else -> arrayOf(w / 2, h * 0.7f, w / 2, h * 0.3f) // up
        }
        val path = Path().apply { moveTo(sx, sy); lineTo(ex, ey) }
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, 300)).build()
        return dispatchGesture(gesture, null, null)
    }

    fun goBack() = performGlobalAction(GLOBAL_ACTION_BACK)
    fun goHome() = performGlobalAction(GLOBAL_ACTION_HOME)

    /** API 30+ screenshot via the accessibility pipeline (no MediaProjection). */
    fun takeScreenshotNow(): Boolean {
        if (Build.VERSION.SDK_INT < 30) return false
        var ok = false
        val latch = java.util.concurrent.CountDownLatch(1)
        takeScreenshot(Display.DEFAULT_DISPLAY,
            mainExecutor,
            object : TakeScreenshotCallback {
                override fun onSuccess(result: ScreenshotResult) {
                    ok = true
                    // Save to Pictures/Avni (bitmap from hardware buffer).
                    try {
                        val bmp = result.hardwareBuffer?.let {
                            android.graphics.Bitmap.wrapHardwareBuffer(it, result.colorSpace)
                        }
                        bmp?.let { saveBitmap(it) }
                    } catch (_: Exception) {}
                    latch.countDown()
                }
                override fun onFailure(errorCode: Int) { latch.countDown() }
            })
        latch.await(3, java.util.concurrent.TimeUnit.SECONDS)
        return ok
    }

    private fun saveBitmap(bmp: android.graphics.Bitmap) {
        val dir = android.os.Environment.getExternalStoragePublicDirectory(
            android.os.Environment.DIRECTORY_PICTURES)
        val file = java.io.File(dir, "Avni/screenshot-${System.currentTimeMillis()}.png")
        file.parentFile?.mkdirs()
        java.io.FileOutputStream(file).use { bmp.compress(android.graphics.Bitmap.CompressFormat.PNG, 100, it) }
    }
}
