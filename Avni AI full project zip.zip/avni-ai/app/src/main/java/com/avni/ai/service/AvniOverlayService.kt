package com.avni.ai.service

import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.os.IBinder
import android.view.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.ComposeView
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.avni.ai.ui.MainActivity
import com.avni.ai.voice.VoicePipeline
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

/**
 * Floating avatar bubble over other apps (SYSTEM_ALERT_WINDOW).
 * Drag to move, tap to talk, long-press to close.
 */
@AndroidEntryPoint
class AvniOverlayService : Service() {
    @Inject lateinit var pipeline: VoicePipeline
    private var view: ComposeView? = null
    private lateinit var params: WindowManager.LayoutParams

    override fun onCreate() {
        super.onCreate()
        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        params = WindowManager.LayoutParams(
            160, 160,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.END; x = 24; y = 300 }
        view = ComposeView(this).apply {
            setContent { Bubble() }
            setOnTouchListener(DragTouch(wm, params))
        }
        wm.addView(view, params)
    }

    @Composable
    private fun Bubble() {
        Box(
            Modifier.size(64.dp).clip(CircleShape)
                .background(Color(0xFF050A14))
                .clickable {
                    startActivity(Intent(this@AvniOverlayService, MainActivity::class.java)
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                },
            contentAlignment = Alignment.Center
        ) { Text("🎙️", fontSize = 28.sp) }
    }

    override fun onDestroy() {
        view?.let { (getSystemService(WINDOW_SERVICE) as WindowManager).removeView(it) }
        super.onDestroy()
    }

    override fun onBind(intent: Intent): IBinder? = null

    private class DragTouch(
        private val wm: WindowManager, private val p: WindowManager.LayoutParams
    ) : View.OnTouchListener {
        private var sx = 0f; private var sy = 0f; private var px = 0; private var py = 0
        override fun onTouch(v: View, e: MotionEvent): Boolean {
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { sx = e.rawX; sy = e.rawY; px = p.x; py = p.y }
                MotionEvent.ACTION_MOVE -> {
                    p.x = px + (sx - e.rawX).toInt()
                    p.y = py + (e.rawY - sy).toInt()
                    wm.updateViewLayout(v, p)
                }
            }
            return false // let clicks through
        }
    }
}
