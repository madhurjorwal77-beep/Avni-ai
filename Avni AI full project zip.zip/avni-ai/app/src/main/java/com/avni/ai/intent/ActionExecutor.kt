package com.avni.ai.intent

import android.app.NotificationManager
import android.content.*
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.os.BatteryManager
import android.provider.AlarmClock
import android.provider.CalendarContract
import android.provider.Settings
import android.widget.Toast
import com.avni.ai.data.db.ActionLogEntry
import com.avni.ai.data.db.AvniDao
import com.avni.ai.data.prefs.SettingsStore
import com.avni.ai.llm.AvniAction
import com.avni.ai.service.AvniAccessibilityService
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.first
import javax.inject.Inject
import javax.inject.Provider
import javax.inject.Singleton

/**
 * Executes validated actions. Safety rules (never bypassed):
 * - call/sms need a spoken confirmation (VoicePipeline) — tracked here.
 * - Banking/UPI apps are blocklisted unless Settings.bankingAllowed is on.
 * - Every action is logged to Room (Action Log screen) with success/failure.
 * - Failures are reported honestly; nothing is faked as done.
 */
@Singleton
class ActionExecutor @Inject constructor(
    @ApplicationContext private val ctx: Context,
    private val dao: AvniDao,
    private val contacts: ContactsHelper,
    private val settings: SettingsStore,
    private val routineProvider: Provider<RoutineEngine>
) {
    private val confirmed = mutableSetOf<Int>()
    fun isConfirmed(a: AvniAction) = confirmed.contains(a.hashCode())
    fun markConfirmed(a: AvniAction) { confirmed += a.hashCode() }

    private val bankingPkgs = listOf(
        "upi", "paytm", "phonepe", "gpay", "googlepay", "bhim", "bank",
        "icici", "hdfc", "sbi", "axis", "kotak", "payzapp", "amazonpay"
    )

    private fun blocked(pkg: String): Boolean =
        bankingPkgs.any { pkg.lowercase().contains(it) }

    suspend fun execute(action: AvniAction): String {
        val result = runCatching { run(action) }
        val text = result.getOrElse { "Nahi ho paya: ${it.message ?: "unknown error"}" }
        dao.insertAction(ActionLogEntry(
            action = action.action, detail = action.params.toString(),
            success = result.isSuccess, undoable = action.action in setOf("torch", "dnd", "volume")
        ))
        return text
    }

    private suspend fun run(a: AvniAction): String {
        val p = a.params
        return when (a.action) {
            "chat" -> a.reply
            "remember" -> {
                p["name"]?.let { dao.upsertFact(com.avni.ai.data.db.MemoryFact(key = "user_name", value = it)) }
                p["fact"]?.let { dao.upsertFact(com.avni.ai.data.db.MemoryFact(key = "custom:${System.currentTimeMillis()}", value = it)) }
                a.reply
            }
            "routine" -> routineProvider.get().run(p["name"] ?: "")
            "torch" -> {
                val cm = ctx.getSystemService(Context.CAMERA_SERVICE) as CameraManager
                val camId = cm.cameraIdList.firstOrNull() ?: return "Camera nahi mila."
                cm.setTorchMode(camId, p["on"] != "false")
                if (p["on"] != "false") "Torch on kar diya." else "Torch band kar diya."
            }
            "volume" -> {
                val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
                val level = (p["level"]?.toIntOrNull() ?: 50).coerceIn(0, 100)
                val max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
                am.setStreamVolume(AudioManager.STREAM_MUSIC, level * max / 100, 0)
                "Volume $level par set kar diya."
            }
            "brightness" -> {
                if (!Settings.System.canWrite(ctx)) {
                    ctx.startActivity(Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS,
                        Uri.parse("package:${ctx.packageName}")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                    return "Brightness badalne ke liye pehle permission deni hogi — settings khol di hai."
                }
                val level = (p["level"]?.toIntOrNull() ?: 50).coerceIn(0, 100)
                Settings.System.putInt(ctx.contentResolver,
                    Settings.System.SCREEN_BRIGHTNESS, level * 255 / 100)
                "Brightness $level par set kar diya."
            }
            "dnd" -> {
                val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
                if (!nm.isNotificationPolicyAccessGranted) {
                    ctx.startActivity(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS)
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                    return "DND ke liye pehle notification policy access dena hoga — settings khol di hai."
                }
                val on = p["on"] != "false"
                nm.setInterruptionFilter(if (on) NotificationManager.INTERRUPTION_FILTER_NONE
                    else NotificationManager.INTERRUPTION_FILTER_ALL)
                if (on) "Do Not Disturb on kar diya." else "Do Not Disturb band kar diya."
            }
            "wifi_panel" -> {
                ctx.startActivity(Intent(Settings.Panel.ACTION_WIFI).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                "WiFi panel khol diya."
            }
            "bluetooth_panel" -> {
                ctx.startActivity(Intent(Settings.Panel.ACTION_BLUETOOTH).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                "Bluetooth panel khol diya."
            }
            "battery" -> {
                val bm = ctx.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
                val pct = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
                val charging = bm.isCharging
                "Battery $pct% hai" + if (charging) " aur charging par hai." else "."
            }
            "clipboard" -> {
                val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                val text = cm.primaryClip?.getItemAt(0)?.text?.toString() ?: ""
                if (text.isBlank()) "Clipboard khaali hai." else "Clipboard mein likha hai: $text"
            }
            "media" -> {
                val cmd = p["cmd"] ?: "play"
                val intent = Intent("android.intent.action.MEDIA_BUTTON")
                ctx.sendBroadcast(intent)
                "Media $cmd bhej diya (jo app chal raha hai us par lagega)."
            }
            "open_app" -> openApp(p["app"] ?: "")
            "call" -> {
                val c = contacts.find(p["name"] ?: "") ?: return "Contact '${p["name"]}' nahi mila."
                val intent = Intent(Intent.ACTION_CALL, Uri.parse("tel:${c.phone}"))
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                ctx.startActivity(intent)
                "${c.name} ko call laga rahi hun."
            }
            "sms" -> {
                val c = contacts.find(p["name"] ?: "") ?: return "Contact '${p["name"]}' nahi mila."
                val intent = Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:${c.phone}"))
                    .putExtra("sms_body", p["text"] ?: "")
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                ctx.startActivity(intent)
                "${c.name} ko message draft khol diya hai."
            }
            "alarm" -> {
                val intent = Intent(AlarmClock.ACTION_SET_ALARM)
                    .putExtra(AlarmClock.EXTRA_MESSAGE, p["label"] ?: "Avni Alarm")
                    .putExtra(AlarmClock.EXTRA_HOUR, p["hour"]?.toIntOrNull() ?: 7)
                    .putExtra(AlarmClock.EXTRA_MINUTES, p["minute"]?.toIntOrNull() ?: 0)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                ctx.startActivity(intent)
                "Alarm set karne ke liye clock khol diya."
            }
            "timer" -> {
                val intent = Intent(AlarmClock.ACTION_SET_TIMER)
                    .putExtra(AlarmClock.EXTRA_LENGTH, p["seconds"]?.toIntOrNull() ?: 60)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                ctx.startActivity(intent)
                "Timer set karne ke liye clock khol diya."
            }
            "calendar" -> {
                if (p["scope"] == "today") {
                    val now = System.currentTimeMillis()
                    val uri = CalendarContract.Instances.CONTENT_URI.buildUpon()
                        .appendPath(now.toString()).appendPath((now + 24 * 3600_000).toString()).build()
                    val titles = mutableListOf<String>()
                    ctx.contentResolver.query(uri,
                        arrayOf(CalendarContract.Instances.TITLE), null, null, null)?.use { c ->
                        while (c.moveToNext()) titles += c.getString(0)
                    }
                    if (titles.isEmpty()) "Aaj koi calendar event nahi hai."
                    else "Aaj ke events: ${titles.joinToString(", ")}."
                } else {
                    val intent = Intent(Intent.ACTION_INSERT)
                        .setData(CalendarContract.Events.CONTENT_URI)
                        .putExtra(CalendarContract.Events.TITLE, p["title"] ?: "Avni Event")
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    ctx.startActivity(intent)
                    "Calendar event banane ke liye calendar khol diya."
                }
            }
            "maps" -> {
                val uri = Uri.parse("geo:0,0?q=${Uri.encode(p["place"] ?: "")}")
                ctx.startActivity(Intent(Intent.ACTION_VIEW, uri).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                "${p["place"]} ka maps khol diya."
            }
            "web_search" -> {
                val uri = Uri.parse("https://www.google.com/search?q=${Uri.encode(p["query"] ?: "")}")
                ctx.startActivity(Intent(Intent.ACTION_VIEW, uri).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                "${p["query"]} search kar diya."
            }
            "camera" -> {
                ctx.startActivity(Intent("android.media.action.IMAGE_CAPTURE").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                "Camera khol diya."
            }
            "screenshot" -> {
                val ok = AvniAccessibilityService.instance?.takeScreenshotNow()
                if (ok == true) "Screenshot le liya." else "Screenshot ke liye Accessibility on karni hogi."
            }
            "screen_read" -> AvniAccessibilityService.instance?.readScreen()
                ?: "Screen padhne ke liye Accessibility on karni hogi."
            "tap_text" -> {
                val ok = AvniAccessibilityService.instance?.tapByText(p["text"] ?: "")
                if (ok == true) "${p["text"]} par tap kar diya." else "Woh button screen par nahi mila."
            }
            "swipe" -> {
                AvniAccessibilityService.instance?.swipe(p["dir"] ?: "up")
                "Swipe kar diya."
            }
            "go_back" -> {
                AvniAccessibilityService.instance?.goBack(); "Back kar diya."
            }
            "go_home" -> {
                AvniAccessibilityService.instance?.goHome(); "Home par le aayi."
            }
            "notify_reply" -> {
                val ok = com.avni.ai.service.AvniNotificationService.replyToLatest(
                    p["app"] ?: "", p["text"] ?: "")
                if (ok) "Jawab bhej diya." else "Us app ka reply wala notification nahi mila."
            }
            else -> "Ye action abhi supported nahi hai."
        }
    }

    private suspend fun openApp(query: String): String {
        val pm = ctx.packageManager
        val q = query.lowercase()
        if (!settings.bankingAllowed.first() && blocked(q))
            return "Banking/UPI apps blocklist mein hain — Settings mein explicitly on karo tabhi kholungi."
        val apps = pm.getInstalledApplications(0)
        val match = apps.firstOrNull {
            pm.getApplicationLabel(it).toString().lowercase().contains(q)
        } ?: apps.firstOrNull { it.packageName.lowercase().contains(q.replace(" ", "")) }
        ?: return "App '$query' nahi mila."
        if (!settings.bankingAllowed.first() && blocked(match.packageName))
            return "Ye banking/UPI app blocklist mein hai."
        val intent = pm.getLaunchIntentForPackage(match.packageName)
            ?: return "Ye app khul nahi paya."
        ctx.startActivity(intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        return "${pm.getApplicationLabel(match)} khol diya."
    }
}
