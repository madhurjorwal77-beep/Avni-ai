package com.avni.ai.data.prefs

import android.content.Context
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import javax.inject.Inject
import javax.inject.Singleton

private val Context.dataStore by preferencesDataStore("avni_settings")

/** All user settings. No setting here ever leaves the device. */
@Singleton
class SettingsStore @Inject constructor(
    @ApplicationContext private val ctx: Context
) {
    companion object {
        val USER_NAME = stringPreferencesKey("user_name")
        val LANG_LOCK = stringPreferencesKey("lang_lock") // "auto" | "hi" | "en"
        val SYSTEM_PROMPT = stringPreferencesKey("system_prompt")
        val TTS_PITCH = floatPreferencesKey("tts_pitch")
        val TTS_RATE = floatPreferencesKey("tts_rate")
        val WAKE_ENABLED = booleanPreferencesKey("wake_enabled")
        val WAKE_SENSITIVITY = floatPreferencesKey("wake_sensitivity")
        val LOW_RAM = booleanPreferencesKey("low_ram")
        val LOW_POWER_AVATAR = booleanPreferencesKey("low_power_avatar")
        val OVERLAY_ENABLED = booleanPreferencesKey("overlay_enabled")
        val BOOT_START = booleanPreferencesKey("boot_start")
        val BANKING_ALLOWED = booleanPreferencesKey("banking_allowed")
        val ONBOARDED = booleanPreferencesKey("onboarded")
        val MODEL_PATH = stringPreferencesKey("model_path")
        val MODEL_ENGINE = stringPreferencesKey("model_engine") // "llama" | "mediapipe" | "rules"
        val AVATAR_VRM_PATH = stringPreferencesKey("avatar_vrm_path")
        val AVATAR_CAMERA = stringPreferencesKey("avatar_camera") // "full" | "bust" | "closeup"
        val AVATAR_HAIR_COLOR = stringPreferencesKey("avatar_hair_color")
    }

    val userName: Flow<String> = ctx.dataStore.data.map { it[USER_NAME] ?: "" }
    val langLock: Flow<String> = ctx.dataStore.data.map { it[LANG_LOCK] ?: "auto" }
    val systemPrompt: Flow<String> = ctx.dataStore.data.map {
        it[SYSTEM_PROMPT] ?: DEFAULT_PROMPT
    }
    val ttsPitch: Flow<Float> = ctx.dataStore.data.map { it[TTS_PITCH] ?: 1.05f }
    val ttsRate: Flow<Float> = ctx.dataStore.data.map { it[TTS_RATE] ?: 1.0f }
    val wakeEnabled: Flow<Boolean> = ctx.dataStore.data.map { it[WAKE_ENABLED] ?: true }
    val wakeSensitivity: Flow<Float> = ctx.dataStore.data.map { it[WAKE_SENSITIVITY] ?: 0.5f }
    val lowRam: Flow<Boolean> = ctx.dataStore.data.map { it[LOW_RAM] ?: false }
    val lowPowerAvatar: Flow<Boolean> = ctx.dataStore.data.map { it[LOW_POWER_AVATAR] ?: false }
    val overlayEnabled: Flow<Boolean> = ctx.dataStore.data.map { it[OVERLAY_ENABLED] ?: false }
    val bootStart: Flow<Boolean> = ctx.dataStore.data.map { it[BOOT_START] ?: false }
    val bankingAllowed: Flow<Boolean> = ctx.dataStore.data.map { it[BANKING_ALLOWED] ?: false }
    val onboarded: Flow<Boolean> = ctx.dataStore.data.map { it[ONBOARDED] ?: false }
    val modelPath: Flow<String> = ctx.dataStore.data.map { it[MODEL_PATH] ?: "" }
    val modelEngine: Flow<String> = ctx.dataStore.data.map { it[MODEL_ENGINE] ?: "llama" }
    val avatarVrmPath: Flow<String> = ctx.dataStore.data.map { it[AVATAR_VRM_PATH] ?: "" }
    val avatarCamera: Flow<String> = ctx.dataStore.data.map { it[AVATAR_CAMERA] ?: "bust" }

    suspend fun set(key: Preferences.Key<String>, value: String) {
        ctx.dataStore.edit { it[key] = value }
    }
    suspend fun set(key: Preferences.Key<Boolean>, value: Boolean) {
        ctx.dataStore.edit { it[key] = value }
    }
    suspend fun set(key: Preferences.Key<Float>, value: Float) {
        ctx.dataStore.edit { it[key] = value }
    }
    suspend fun clearAll() { ctx.dataStore.edit { it.clear() } }

    companion object {
        const val DEFAULT_PROMPT =
            "You are Avni, a friendly, witty, Jarvis-like voice assistant on the user's " +
            "phone. Answer in the user's language (Hindi, English or Hinglish). Keep " +
            "replies short and spoken-friendly (1-3 sentences) unless asked for detail. " +
            "For phone actions, reply ONLY with strict JSON: " +
            """{"action":"<name>","params":{...},"reply":"<spoken reply>"}""" +
            " Valid actions: open_app, call, sms, alarm, timer, calendar, maps, " +
            "web_search, camera, torch, volume, brightness, dnd, wifi_panel, " +
            "bluetooth_panel, battery, clipboard, media, screenshot, screen_read, " +
            "tap_text, swipe, go_back, go_home, notify_reply, routine, remember, chat. " +
            "Prefix emotion tags like [happy] or [sad] at the start of reply when fitting."
    }
}
