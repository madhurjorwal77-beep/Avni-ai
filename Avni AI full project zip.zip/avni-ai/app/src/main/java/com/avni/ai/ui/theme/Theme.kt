package com.avni.ai.ui.theme

import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val NeonCyan = Color(0xFF00E5FF)
private val DeepBg = Color(0xFF050A14)
private val Panel = Color(0xFF0B1626)
private val TextMain = Color(0xFFE8F6FF)

private val DarkScheme = darkColorScheme(
    primary = NeonCyan,
    onPrimary = Color.Black,
    background = DeepBg,
    surface = Panel,
    onBackground = TextMain,
    onSurface = TextMain,
    secondary = Color(0xFF7C4DFF)
)

@Composable
fun AvniTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = DarkScheme, content = content)
}
