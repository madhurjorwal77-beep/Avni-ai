package com.avni.ai.avatar

import android.annotation.SuppressLint
import android.content.Context
import android.webkit.JavascriptInterface
import android.webkit.WebView
import com.avni.ai.voice.AvatarState
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.StateFlow

/**
 * Kotlin <-> JS bridge for the avatar WebView. All calls are funneled
 * through evaluateJavascript on the main thread; viseme/state flows from
 * the VoicePipeline are forwarded here by the Main screen.
 */
class AvatarBridge(private val webView: WebView) {
    var onVrmLoaded: ((String) -> Unit)? = null

    @JavascriptInterface
    fun onVrmLoaded(status: String) { onVrmLoaded?.invoke(status) }

    fun setState(state: AvatarState) {
        val s = when (state) {
            AvatarState.IDLE -> "idle"; AvatarState.LISTENING -> "listening"
            AvatarState.THINKING -> "thinking"; AvatarState.SPEAKING -> "speaking"
            AvatarState.HAPPY -> "happy"; AvatarState.SAD -> "sad"
            AvatarState.SURPRISED -> "surprised"; AvatarState.ANGRY -> "angry"
            AvatarState.SLEEPING -> "sleeping"
        }
        eval("window.AvniAvatar && AvniAvatar.setState('$s')")
    }

    /** "aa:0.9" -> setViseme('aa', 0.9) */
    fun setViseme(spec: String) {
        val parts = spec.split(":")
        if (parts.size == 2) {
            val v = parts[1].toFloatOrNull() ?: 0f
            eval("window.AvniAvatar && AvniAvatar.setViseme('${parts[0]}', $v)")
        }
    }

    fun setCamera(mode: String) = eval("window.AvniAvatar && AvniAvatar.setCamera('$mode')")
    fun setLowPower(low: Boolean) = eval("window.AvniAvatar && AvniAvatar.setLowPower($low)")
    fun gesture(kind: String) = eval("window.AvniAvatar && AvniAvatar.gesture('$kind')")
    fun setHairColor(hex: String) = eval("window.AvniAvatar && AvniAvatar.setHairColor('$hex')")

    /** Load a user .vrm file copied into internal storage (served via file URL). */
    fun loadVrmFile(absPath: String) {
        eval("window.AvniAvatar && AvniAvatar.loadVrm('file://$absPath')")
    }

    private fun eval(js: String) {
        webView.post { webView.evaluateJavascript(js, null) }
    }
}

/**
 * Builds the avatar WebView: local assets only, JS enabled, no remote URLs.
 * The created bridge is handed back via [onBridge] so Compose can forward
 * voice-pipeline state/visemes into it.
 */
@SuppressLint("SetJavaScriptEnabled")
fun createAvatarWebView(ctx: Context, onBridge: (AvatarBridge) -> Unit): WebView {
    lateinit var bridge: AvatarBridge
    return WebView(ctx).apply {
        bridge = AvatarBridge(this)
        settings.javaScriptEnabled = true
        settings.domStorageEnabled = true
        settings.allowFileAccess = true
        settings.allowContentAccess = true
        settings.mediaPlaybackRequiresUserGesture = false
        addJavascriptInterface(bridge, "AvniBridge")
        loadUrl("file:///android_asset/avatar/index.html")
        onBridge(bridge)
    }
}
