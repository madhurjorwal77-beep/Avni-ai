package com.avni.ai.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.avni.ai.data.db.AvniDao
import com.avni.ai.data.prefs.SettingsStore
import com.avni.ai.voice.VoicePipeline
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class MainViewModel @Inject constructor(
    val pipeline: VoicePipeline,
    private val dao: AvniDao,
    val settings: SettingsStore
) : ViewModel() {
    val transcript = pipeline.transcript
    val avatarState = pipeline.avatarState
    val viseme = pipeline.viseme

    val chats = flow { while (true) { emit(dao.recentChats(50)); kotlinx.coroutines.delay(2000) } }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val actions = flow { while (true) { emit(dao.recentActions()); kotlinx.coroutines.delay(2000) } }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val facts = flow { while (true) { emit(dao.allFacts()); kotlinx.coroutines.delay(2000) } }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val routines = flow { while (true) { emit(dao.allRoutines()); kotlinx.coroutines.delay(2000) } }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun talk() = pipeline.runOnce()
    fun sendText(text: String) = pipeline.handleTextInput(text)

    fun deleteFact(key: String) = viewModelScope.launch { dao.deleteFact(key) }
    fun deleteRoutine(id: Long) = viewModelScope.launch { dao.deleteRoutine(id) }
    fun clearAllData() = viewModelScope.launch {
        dao.clearChats(); dao.clearFacts(); dao.clearActions()
        settings.clearAll()
    }
}
