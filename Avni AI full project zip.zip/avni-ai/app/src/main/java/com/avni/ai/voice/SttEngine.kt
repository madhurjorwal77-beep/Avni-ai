package com.avni.ai.voice

import android.content.Context
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import org.json.JSONObject
import org.vosk.Model
import org.vosk.Recognizer
import org.vosk.android.RecognitionListener
import org.vosk.android.SpeechService
import org.vosk.android.SpeechStreamService
import java.io.File
import java.io.FileOutputStream
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Offline STT via Vosk. Models ship in assets/models/vosk/{hi,en} and are
 * copied to internal storage on first use (no download, no network).
 * Wake word uses a tiny grammar recognizer ("hey avni") so the mic can
 * listen cheaply in the background; full dictation uses the full model.
 */
@Singleton
class SttEngine @Inject constructor(
    @ApplicationContext private val ctx: Context
) {
    private var modelHi: Model? = null
    private var modelEn: Model? = null
    private var speechService: SpeechService? = null
    private var wakeService: SpeechService? = null

    private val _partial = MutableStateFlow("")
    val partial: StateFlow<String> = _partial.asStateFlow()

    private fun assetModelDir(lang: String): File {
        val out = File(ctx.filesDir, "vosk/$lang")
        if (File(out, "final.mdl").exists() || File(out, "am").exists()) return out
        out.mkdirs()
        copyAssetDir("models/vosk/$lang", out)
        return out
    }

    private fun copyAssetDir(assetPath: String, out: File) {
        val list = ctx.assets.list(assetPath) ?: return
        for (name in list) {
            val childAsset = "$assetPath/$name"
            val childOut = File(out, name)
            if ((ctx.assets.list(childAsset)?.isNotEmpty() == true)) {
                childOut.mkdirs(); copyAssetDir(childAsset, childOut)
            } else {
                ctx.assets.open(childAsset).use { input ->
                    FileOutputStream(childOut).use { input.copyTo(it) }
                }
            }
        }
    }

    private fun model(lang: String): Model {
        if (lang == "hi") return modelHi ?: Model(assetModelDir("hi").absolutePath).also { modelHi = it }
        return modelEn ?: Model(assetModelDir("en").absolutePath).also { modelEn = it }
    }

    /**
     * One-shot dictation. [lang] "hi" uses the Hindi model (handles Roman
     * Hindi poorly — so Hinglish input falls back: if the Hindi result is
     * empty, retry with English). Returns final text or "".
     */
    suspend fun listenOnce(lang: String, timeoutMs: Long = 20_000): String {
        val result = CompletableDeferred<String>()
        val chosen = if (lang == "hi") "hi" else "en"
        val rec = Recognizer(model(chosen), 16000f)
        val service = SpeechService(rec, 16000f)
        speechService = service
        service.startListening(object : RecognitionListener {
            override fun onPartialResult(hyp: String) {
                _partial.value = JSONObject(hyp).optString("partial")
            }
            override fun onResult(hyp: String) {
                val text = JSONObject(hyp).optString("text")
                if (text.isNotBlank()) result.complete(text)
            }
            override fun onFinalResult(hyp: String) {
                val text = JSONObject(hyp).optString("text")
                if (!result.isCompleted) {
                    if (text.isNotBlank()) result.complete(text)
                    else if (chosen == "hi") {
                        // Retry Hinglish with the English model.
                        CoroutineScope(Dispatchers.IO).launch {
                            result.complete(listenOnce("en", timeoutMs))
                        }
                        return
                    } else result.complete("")
                }
            }
            override fun onError(e: Exception) {
                if (!result.isCompleted) result.completeExceptionally(e)
            }
            override fun onTimeout() {
                if (!result.isCompleted) result.complete("")
            }
        })
        return try {
            withTimeoutOrNull(timeoutMs) { result.await() } ?: ""
        } finally {
            service.stop(); service.shutdown()
        }
    }

    /** Continuous wake-word listening. Calls [onWake] when "hey avni" is heard. */
    fun startWakeWord(sensitivity: Float, onWake: () -> Unit) {
        if (wakeService != null) return
        val rec = Recognizer(model("en"), 16000f,
            "[\"hey avni\", \"hey avani\", \"avni\", \"[unk]\"]")
        val service = SpeechService(rec, 16000f)
        wakeService = service
        service.startListening(object : RecognitionListener {
            override fun onPartialResult(hyp: String) {
                val p = JSONObject(hyp).optString("partial").lowercase()
                if (p.contains("avni") || p.contains("avani")) {
                    // Grammar mode fires on partial; require the full phrase.
                    if (p.contains("hey")) { stopWakeWord(); onWake() }
                }
            }
            override fun onResult(hyp: String) {
                val t = JSONObject(hyp).optString("text").lowercase()
                if (t.contains("avni") || t.contains("avani")) { stopWakeWord(); onWake() }
            }
            override fun onFinalResult(hyp: String) {}
            override fun onError(e: Exception) {}
            override fun onTimeout() {}
        })
    }

    fun stopWakeWord() {
        wakeService?.stop(); wakeService?.shutdown(); wakeService = null
    }

    fun stopAll() {
        speechService?.stop(); speechService?.shutdown(); speechService = null
        stopWakeWord()
    }
}
