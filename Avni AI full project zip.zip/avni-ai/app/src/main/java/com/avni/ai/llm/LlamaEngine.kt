package com.avni.ai.llm

import android.content.Context
import android.os.PowerManager
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.*
import javax.inject.Inject
import javax.inject.Singleton

/**
 * JNI bridge to llama.cpp. The native lib is built from
 * app/src/main/cpp/llama.cpp (fetched by scripts/fetch-assets.sh).
 * If the native lib is absent (e.g. llama.cpp not fetched), every call
 * returns false/empty and HybridChatEngine falls back cleanly — the app
 * never crashes and never pretends the model answered.
 */
@Singleton
class LlamaEngine @Inject constructor(
    @ApplicationContext private val ctx: Context
) {
    private external fun nativeInit(modelPath: String, nCtx: Int, nThreads: Int): Boolean
    private external fun nativeComplete(prompt: String, maxTokens: Int): String
    private external fun nativeFree()
    private external fun nativeIsLoaded(): Boolean

    @Volatile private var loaded = false
    @Volatile private var loading = false
    private var lastUsed = 0L
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    companion object {
        init {
            try { System.loadLibrary("avni_llama") } catch (_: Throwable) { /* fallback path */ }
        }
    }

    val isLoaded: Boolean get() = loaded && nativeIsLoadedSafe()

    private fun nativeIsLoadedSafe(): Boolean = try { nativeIsLoaded() } catch (_: Throwable) { false }

    suspend fun load(modelPath: String, lowRam: Boolean): Boolean {
        if (loaded) return true
        if (loading) return false
        loading = true
        return try {
            val nCtx = if (lowRam) 1024 else 2048
            val threads = Runtime.getRuntime().availableProcessors().coerceAtMost(4)
            loaded = withContext(Dispatchers.IO) {
                try { nativeInit(modelPath, nCtx, threads) } catch (_: Throwable) { false }
            }
            if (loaded) {
                lastUsed = System.currentTimeMillis()
                startIdleUnloadWatcher()
            }
            loaded
        } finally { loading = false }
    }

    /** Stream-free completion; llama.cpp samples the whole reply (fast for short replies). */
    suspend fun complete(prompt: String, maxTokens: Int = 256): String {
        if (!isLoaded) return ""
        lastUsed = System.currentTimeMillis()
        return withContext(Dispatchers.IO) {
            try { nativeComplete(prompt, maxTokens) } catch (_: Throwable) { "" }
        }
    }

    fun unload() {
        try { nativeFree() } catch (_: Throwable) {}
        loaded = false
    }

    /** Unload after 10 idle minutes to free RAM; also on thermal throttling. */
    private fun startIdleUnloadWatcher() {
        scope.launch {
            while (loaded) {
                delay(60_000)
                val pm = ctx.getSystemService(Context.POWER_SERVICE) as PowerManager
                val hot = android.os.Build.VERSION.SDK_INT >= 29 &&
                    pm.currentThermalStatus >= PowerManager.THERMAL_STATUS_MODERATE
                if (hot || System.currentTimeMillis() - lastUsed > 10 * 60_000) unload()
            }
        }
    }
}
