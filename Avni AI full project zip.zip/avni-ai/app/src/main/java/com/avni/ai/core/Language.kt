package com.avni.ai.core

/** Tiny Hinglish detector: Devanagari presence + Hindi word list. No network. */
object Language {
    private val hindiWords = setOf(
        "karo", "bhejo", "kholo", "band", "chalu", "kya", "kaise", "kab", "kahan",
        "mera", "meri", "mujhe", "tum", "aap", "hai", "hain", "nahi", "aur",
        "batao", "sunao", "dikhao", "lagao", "uthao", "rakho", "yaad", "aaj",
        "kal", "subah", "shaam", "raat", "paani", "khana", "gana", "photo"
    )
    private val devanagari = '\u0900'..'\u097F'

    /** Returns "hi" (Devanagari or Hindi words), "hinglish" (Latin Hindi mix) or "en". */
    fun detect(text: String): String {
        if (text.any { it in devanagari }) return "hi"
        val words = text.lowercase().split(Regex("[^a-z]+")).filter { it.isNotBlank() }
        if (words.isEmpty()) return "en"
        val hits = words.count { it in hindiWords }
        return when {
            hits >= 2 -> "hinglish"
            hits == 1 && words.size <= 4 -> "hinglish"
            else -> "en"
        }
    }

    fun ttsLocale(lang: String): java.util.Locale = when (lang) {
        "hi" -> java.util.Locale("hi", "IN")
        "hinglish" -> java.util.Locale("hi", "IN") // Hindi voice reads Roman Hindi best
        else -> java.util.Locale("en", "IN")
    }
}
