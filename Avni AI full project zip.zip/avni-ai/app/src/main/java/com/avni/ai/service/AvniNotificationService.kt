package com.avni.ai.service

import android.app.Notification
import android.app.RemoteInput
import android.content.Intent
import android.os.Bundle
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

/**
 * Reads notifications (for spoken summaries) and replies by voice via
 * RemoteInput on the notification's own reply action. Only the latest
 * notification per app is kept; nothing is stored beyond the session.
 */
class AvniNotificationService : NotificationListenerService() {

    companion object {
        private val latest = mutableMapOf<String, StatusBarNotification>()
        var onNotification: ((app: String, title: String, text: String) -> Unit)? = null

        /** Voice reply to the latest notification from [appQuery]. */
        fun replyToLatest(appQuery: String, text: String): Boolean {
            val sbn = latest.entries.firstOrNull {
                it.key.contains(appQuery, ignoreCase = true) ||
                    it.value.packageName.contains(appQuery, ignoreCase = true)
            }?.value ?: return false
            for (action in sbn.notification.actions ?: emptyArray()) {
                val remoteInputs = action.remoteInputs ?: continue
                if (remoteInputs.isEmpty()) continue
                val intent = Intent()
                val bundle = Bundle()
                for (ri in remoteInputs) bundle.putCharSequence(ri.resultKey, text)
                RemoteInput.addResultsToIntent(remoteInputs, intent, bundle)
                try {
                    action.actionIntent.send(null, 0, intent)
                    return true
                } catch (_: Exception) { return false }
            }
            return false
        }
    }

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        val extras = sbn.notification.extras
        val title = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString() ?: ""
        val text = extras.getCharSequence(Notification.EXTRA_TEXT)?.toString() ?: ""
        if (title.isBlank() && text.isBlank()) return
        latest[sbn.packageName] = sbn
        onNotification?.invoke(sbn.packageName, title, text)
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification) {
        if (latest[sbn.packageName] == sbn) latest.remove(sbn.packageName)
    }
}
