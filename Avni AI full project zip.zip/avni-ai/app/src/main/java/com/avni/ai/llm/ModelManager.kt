package com.avni.ai.llm

import android.content.Context
import android.net.Uri
import com.avni.ai.data.prefs.SettingsStore
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import java.io.*
import java.net.HttpURLConnection
import java.net.URL
import javax.inject.Inject
import javax.inject.Singleton

sealed class DownloadState {
    data object Idle : DownloadState()
    data class Progress(val downloaded: Long, val total: Long) : DownloadState()
    data class Done(val path: String) : DownloadState()
    data class Error(val msg: String) : DownloadState()
}

/**
 * GGUF model manager. Downloads from Hugging Face with HTTP Range resume
 * (partial file is kept, next run continues), or imports a local .gguf
 * picked by the user (SAF). Progress is a StateFlow for the UI.
 */
@Singleton
class ModelManager @Inject constructor(
    @ApplicationContext private val ctx: Context,
    private val settings: SettingsStore
) {
    private val _state = MutableStateFlow<DownloadState>(DownloadState.Idle)
    val state: StateFlow<DownloadState> = _state.asStateFlow()

    private var job: Job? = null

    fun modelsDir(): File = File(ctx.filesDir, "models").apply { mkdirs() }
    fun defaultModelFile(): File = File(modelsDir(), "qwen2.5-1.5b-instruct-q4_k_m.gguf")

    fun download(url: String) {
        job?.cancel()
        job = CoroutineScope(Dispatchers.IO).launch {
            val out = defaultModelFile()
            try {
                var downloaded = if (out.exists()) out.length() else 0L
                val conn = (URL(url).openConnection() as HttpURLConnection).apply {
                    if (downloaded > 0) setRequestProperty("Range", "bytes=$downloaded-")
                    connectTimeout = 30_000; readTimeout = 30_000; connect()
                }
                val total = if (conn.responseCode == 206) {
                    downloaded + conn.contentLengthLong
                } else {
                    downloaded = 0; conn.contentLengthLong
                }
                BufferedInputStream(conn.inputStream).use { input ->
                    FileOutputStream(out, downloaded > 0).use { output ->
                        val buf = ByteArray(64 * 1024)
                        var n: Int
                        var lastEmit = 0L
                        while (input.read(buf).also { n = it } != -1) {
                            ensureActive()
                            output.write(buf, 0, n)
                            downloaded += n
                            if (System.currentTimeMillis() - lastEmit > 300) {
                                _state.value = DownloadState.Progress(downloaded, total)
                                lastEmit = System.currentTimeMillis()
                            }
                        }
                    }
                }
                _state.value = DownloadState.Done(out.absolutePath)
                settings.set(SettingsStore.MODEL_PATH, out.absolutePath)
            } catch (e: CancellationException) {
                _state.value = DownloadState.Error("Paused — dobara shuru karo, resume hoga.")
            } catch (e: Exception) {
                _state.value = DownloadState.Error(e.message ?: "Download fail")
            }
        }
    }

    fun cancel() { job?.cancel() }

    /** Copy a user-picked .gguf (SAF Uri) into internal storage. */
    suspend fun importFromUri(uri: Uri): Result<String> = withContext(Dispatchers.IO) {
        runCatching {
            val out = File(modelsDir(), "imported-${System.currentTimeMillis()}.gguf")
            ctx.contentResolver.openInputStream(uri)?.use { input ->
                FileOutputStream(out).use { input.copyTo(it) }
            } ?: throw IOException("File khul nahi paya")
            settings.set(SettingsStore.MODEL_PATH, out.absolutePath)
            out.absolutePath
        }
    }
}
