package com.avni.ai.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.avni.ai.ui.MainViewModel

@Composable
fun BackBar(nav: NavController, title: String) {
    Row(Modifier.fillMaxWidth().padding(8.dp)) {
        OutlinedButton(onClick = { nav.popBackStack() }) { Text("← Back") }
        Text(title, Modifier.padding(start = 12.dp, top = 10.dp),
            style = MaterialTheme.typography.titleMedium)
    }
}

@Composable
fun OnboardingScreen(onDone: () -> Unit, onOpenSettings: (String) -> Unit) {
    val items = listOf(
        Triple("Microphone", "Avni ko sunne ke liye — wake word aur voice commands ke liye zaroori hai. Audio kabhi server par nahi jaata.", "mic"),
        Triple("Contacts", "Naam se call/message karne ke liye — jaise 'Rahul ko call karo'. Contacts sirf phone mein hi rehte hain.", "contacts"),
        Triple("Notifications", "Notifications padh kar sunane aur unka voice se jawab dene ke liye.", "notification"),
        Triple("Accessibility", "Kisi bhi app ko chalane ke liye — screen padhna, button dabana, text type karna. Ye sirf tumhare kehne par hota hai.", "accessibility"),
        Triple("Overlay", "Dusre apps ke upar chhota avatar bubble dikhane ke liye, taaki kahin se bhi baat kar sako.", "overlay"),
    )
    Column(Modifier.fillMaxSize().padding(16.dp).verticalScroll(rememberScrollState())) {
        Text("Namaste! Main Avni hun 👋", style = MaterialTheme.typography.headlineSmall)
        Text("Poori tarah offline, tumhare phone par hi chalne wali assistant. " +
            "Ye permissions sirf wahi features ke liye chahiye jo tum chahoge — " +
            "kuch skip karna ho to bhi aage badh sakte ho.",
            Modifier.padding(vertical = 12.dp))
        items.forEach { (title, desc, kind) ->
            Card(Modifier.fillMaxWidth().padding(vertical = 6.dp)) {
                Column(Modifier.padding(12.dp)) {
                    Text(title, style = MaterialTheme.typography.titleMedium)
                    Text(desc, Modifier.padding(vertical = 4.dp))
                    if (kind in setOf("accessibility", "notification", "overlay")) {
                        OutlinedButton(onClick = { onOpenSettings(kind) }) { Text("Settings kholo") }
                    }
                }
            }
        }
        Button(onClick = onDone, modifier = Modifier.fillMaxWidth().padding(top = 16.dp)) {
            Text("Shuru karo")
        }
    }
}

@Composable
fun ChatScreen(vm: MainViewModel, nav: NavController) {
    val chats by vm.chats.collectAsState()
    Column(Modifier.fillMaxSize()) {
        BackBar(nav, "Chat History")
        LazyColumn(Modifier.weight(1f).padding(horizontal = 12.dp)) {
            items(chats.reversed()) { m ->
                Card(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                    Column(Modifier.padding(10.dp)) {
                        Text(if (m.role == "user") "Tum" else "Avni",
                            color = MaterialTheme.colorScheme.primary)
                        Text(m.text)
                    }
                }
            }
        }
    }
}

@Composable
fun MemoryScreen(vm: MainViewModel, nav: NavController) {
    val facts by vm.facts.collectAsState()
    Column(Modifier.fillMaxSize()) {
        BackBar(nav, "Memory Manager")
        Text("Avni ne ye baatein yaad rakhi hain — kisi ko bhi hata sakte ho.",
            Modifier.padding(12.dp))
        LazyColumn(Modifier.weight(1f).padding(horizontal = 12.dp)) {
            items(facts) { f ->
                Card(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                    Row(Modifier.padding(10.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("${f.key}: ${f.value}", Modifier.weight(1f))
                        OutlinedButton(onClick = { vm.deleteFact(f.key) }) { Text("Delete") }
                    }
                }
            }
        }
    }
}

@Composable
fun RoutinesScreen(vm: MainViewModel, nav: NavController) {
    val routines by vm.routines.collectAsState()
    Column(Modifier.fillMaxSize()) {
        BackBar(nav, "Routines / Macros")
        Text("Built-in: 'good morning' (battery + calendar + summary), 'good night' (DND on). " +
            "Apni macro banane ke liye trigger phrase + steps JSON Room mein save hote hain.",
            Modifier.padding(12.dp))
        LazyColumn(Modifier.weight(1f).padding(horizontal = 12.dp)) {
            items(routines) { r ->
                Card(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                    Row(Modifier.padding(10.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("'${r.trigger}' → ${r.stepsJson}", Modifier.weight(1f))
                        OutlinedButton(onClick = { vm.deleteRoutine(r.id) }) { Text("Delete") }
                    }
                }
            }
        }
    }
}

@Composable
fun ActionLogScreen(vm: MainViewModel, nav: NavController) {
    val actions by vm.actions.collectAsState()
    Column(Modifier.fillMaxSize()) {
        BackBar(nav, "Action Log")
        LazyColumn(Modifier.weight(1f).padding(horizontal = 12.dp)) {
            items(actions) { a ->
                Card(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                    Column(Modifier.padding(10.dp)) {
                        Text("${a.action} — ${if (a.success) "✓" else "✗ fail"}")
                        Text(a.detail, style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
        }
    }
}

@Composable
fun AboutScreen(nav: NavController) {
    Column(Modifier.fillMaxSize().padding(16.dp).verticalScroll(rememberScrollState())) {
        BackBar(nav, "About")
        Text("Avni AI v1.0.0", style = MaterialTheme.typography.headlineSmall)
        Text(
            "Fully offline Jarvis-style assistant. Koi cloud nahi, koi API key nahi, " +
            "koi analytics nahi. Sab kuch tumhare phone par: Vosk STT, Android TTS, " +
            "on-device LLM (llama.cpp), Three.js/VRM avatar. Data sirf encrypted " +
            "local database mein rehta hai.",
            Modifier.padding(vertical = 12.dp)
        )
        Text("Limitations (imaandari se): on-device 1.5B model cloud models se dheema " +
            "aur kamzor hai; Vosk small models naam kabhi galat sun sakte hain — " +
            "isliye call/message se pehle confirmation mangi jaati hai; banking/UPI " +
            "apps default blocklist mein hain.",
            Modifier.padding(vertical = 8.dp))
    }
}
