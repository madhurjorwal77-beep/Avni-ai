package com.avni.ai.service

import android.app.*
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.avni.ai.R
import com.avni.ai.ui.MainActivity
import com.avni.ai.voice.VoicePipeline
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

/**
 * Foreground service that owns wake-word listening. The persistent
 * notification keeps the mic alive within Android's background limits.
 * Battery note: wake word uses the small Vosk grammar recognizer, not the
 * full model, and pauses while a call is active (handled by the pipeline).
 */
@AndroidEntryPoint
class AvniVoiceService : Service() {
    @Inject lateinit var pipeline: VoicePipeline

    companion object {
        const val CHANNEL = "avni_voice"
        const val NOTIF_ID = 1001
        fun start(ctx: Context) {
            val intent = Intent(ctx, AvniVoiceService::class.java)
            if (Build.VERSION.SDK_INT >= 26) ctx.startForegroundService(intent)
            else ctx.startService(intent)
        }
        fun stop(ctx: Context) = ctx.stopService(Intent(ctx, AvniVoiceService::class.java))
    }

    override fun onCreate() {
        super.onCreate()
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(NotificationChannel(
                CHANNEL, "Avni Voice", NotificationManager.IMPORTANCE_LOW))
        }
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val notif = NotificationCompat.Builder(this, CHANNEL)
            .setContentTitle("Avni sun rahi hai")
            .setContentText("'Hey Avni' bolo, ya tap karo")
            .setSmallIcon(R.drawable.ic_mic)
            .setContentIntent(open)
            .setOngoing(true)
            .build()
        startForeground(NOTIF_ID, notif)
        pipeline.startWakeWord()
    }

    override fun onDestroy() {
        pipeline.stopWakeWord()
        super.onDestroy()
    }

    override fun onBind(intent: Intent): IBinder? = null
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        return START_STICKY
    }
}
