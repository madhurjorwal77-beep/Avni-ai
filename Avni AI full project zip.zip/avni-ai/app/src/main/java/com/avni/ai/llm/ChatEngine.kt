package com.avni.ai.llm

import com.avni.ai.data.db.AvniDao
import com.avni.ai.data.prefs.SettingsStore
import kotlinx.coroutines.flow.first
import org.json.JSONObject

/** Validated LLM output. [action] "chat" means plain conversation. */
data class AvniAction(
    val action: String,
    val params: Map<String, String>,
    val reply: String,
    val emotion: String = "neutral"
)

interface ChatEngine {
    /** [history] = last turns, oldest first. Returns action or chat reply. */
    suspend fun respond(userText: String, history: List<Pair<String, String>>): AvniAction
}

private val VALID_ACTIONS = setOf(
    "open_app", "call", "sms", "alarm", "timer", "calendar", "maps", "web_search",
    "camera", "torch", "volume", "brightness", "dnd", "wifi_panel",
    "bluetooth_panel", "battery", "clipboard", "media", "screenshot",
    "screen_read", "tap_text", "swipe", "go_back", "go_home", "notify_reply",
    "routine", "remember", "chat"
)

/** Strict JSON parsing with 2 retries handled by the caller. */
object ActionJson {
    fun parse(raw: String): AvniAction? {
        val start = raw.indexOf('{'); val end = raw.lastIndexOf('}')
        if (start < 0 || end <= start) return null
        return try {
            val j = JSONObject(raw.substring(start, end + 1))
            val action = j.optString("action", "chat")
            if (action !in VALID_ACTIONS) return null
            val params = mutableMapOf<String, String>()
            val p = j.optJSONObject("params")
            if (p != null) for (k in p.keys()) params[k] = p.optString(k)
            var reply = j.optString("reply", "")
            var emotion = "neutral"
            // Emotion tags like "[happy] ..." at the reply start.
            val tag = Regex("^\\[(happy|sad|surprised|angry)\\]\\s*").find(reply)
            if (tag != null) { emotion = tag.groupValues[1]; reply = reply.removePrefix(tag.value) }
            if (reply.isBlank()) return null
            AvniAction(action, params, reply, emotion)
        } catch (_: Exception) { null }
    }
}

/**
 * Hybrid engine: llama.cpp if a model is loaded, else the rule engine.
 * LLM path: system prompt + short history + user text -> strict JSON,
 * retry once with a "reply ONLY with JSON" nudge, then chat fallback.
 */
class HybridChatEngine(
    private val llama: LlamaEngine,
    private val settings: SettingsStore,
    private val dao: AvniDao
) : ChatEngine {
    private val rules = RuleChatEngine()

    override suspend fun respond(userText: String, history: List<Pair<String, String>>): AvniAction {
        val modelPath = settings.modelPath.first()
        if (modelPath.isNotBlank() && !llama.isLoaded) {
            llama.load(modelPath, settings.lowRam.first())
        }
        if (llama.isLoaded) {
            val system = settings.systemPrompt.first()
            val userName = settings.userName.first()
            val facts = dao.allFacts().take(20)
                .joinToString("\n") { "- ${it.key}: ${it.value}" }
            val hist = history.takeLast(6)
                .joinToString("\n") { (r, t) -> "${if (r == "user") "User" else "Avni"}: $t" }
            val prompt = buildString {
                append("<|im_start|>system\n$system\n")
                if (userName.isNotBlank()) append("User ka naam: $userName.\n")
                if (facts.isNotBlank()) append("Yaad rakhi baatein:\n$facts\n")
                append("<|im_end|>\n")
                if (hist.isNotBlank()) append("$hist\n")
                append("<|im_start|>user\n$userText<|im_end|>\n<|im_start|>assistant\n")
            }
            var raw = llama.complete(prompt, 256)
            var parsed = ActionJson.parse(raw)
            if (parsed == null) {
                raw = llama.complete("$prompt\n(Reply ONLY with the JSON object, nothing else.)", 256)
                parsed = ActionJson.parse(raw)
            }
            if (parsed != null) return parsed
            // LLM answered but not in JSON: use its text as a chat reply.
            val clean = raw.trim().removePrefix("<|im_start|>assistant").trim()
            if (clean.isNotBlank()) return AvniAction("chat", emptyMap(), clean.take(500))
        }
        return rules.respond(userText, history)
    }
}
