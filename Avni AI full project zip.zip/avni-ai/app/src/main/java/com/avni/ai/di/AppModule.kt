package com.avni.ai.di

import android.content.Context
import androidx.room.Room
import com.avni.ai.data.db.AvniDatabase
import com.avni.ai.data.prefs.SettingsStore
import com.avni.ai.llm.ChatEngine
import com.avni.ai.llm.HybridChatEngine
import com.avni.ai.llm.LlamaEngine
import com.avni.ai.llm.ModelManager
import com.avni.ai.voice.SttEngine
import com.avni.ai.voice.TtsEngine
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import net.sqlcipher.database.SQLiteDatabase
import net.sqlcipher.database.SupportFactory
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object AppModule {

    /** Encrypted Room DB. Key lives in AndroidKeyStore (see Crypto.kt). */
    @Provides @Singleton
    fun provideDb(@ApplicationContext ctx: Context): AvniDatabase {
        SQLiteDatabase.loadLibs(ctx)
        val key = com.avni.ai.core.Crypto.dbKey(ctx)
        val factory = SupportFactory(key)
        return Room.databaseBuilder(ctx, AvniDatabase::class.java, "avni.db")
            .openHelperFactory(factory)
            .fallbackToDestructiveMigration()
            .build()
    }

    @Provides @Singleton fun provideDao(db: AvniDatabase) = db.dao()
    @Provides @Singleton fun provideSettings(@ApplicationContext c: Context) = SettingsStore(c)
    @Provides @Singleton fun provideTts(@ApplicationContext c: Context, s: SettingsStore) = TtsEngine(c, s)
    @Provides @Singleton fun provideStt(@ApplicationContext c: Context) = SttEngine(c)
    @Provides @Singleton fun provideLlama(@ApplicationContext c: Context) = LlamaEngine(c)
    @Provides @Singleton fun provideModelManager(@ApplicationContext c: Context, s: SettingsStore) = ModelManager(c, s)
    @Provides @Singleton
    fun provideChatEngine(
        llama: LlamaEngine, settings: SettingsStore, db: AvniDatabase
    ): ChatEngine = HybridChatEngine(llama, settings, db.dao())
}
