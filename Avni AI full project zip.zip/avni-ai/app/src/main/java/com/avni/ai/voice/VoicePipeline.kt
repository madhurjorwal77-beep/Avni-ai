package com.avni.ai.voice

import com.avni.ai.data.db.AvniDao
import com.avni.ai.data.db.ChatMessage
import com.avni.ai.data.prefs.SettingsStore
import com.avni.ai.intent.ActionExecutor
import com.avni.ai.llm.ChatEngine
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import javax.inject.Inject
import javax.inject.Singleton

/**
 * The full loop: tap/wake -> STT -> LLM/rules -> action -> TTS reply.
 * Also owns the pending-confirmation flow: dangerous actions (call/sms)
 * speak a confirmation and wait for a yes/no voice answer.
 */
@Singleton
class VoicePipeline @Inject constructor(
    private val stt: SttEngine,
    private val tts: TtsEngine,
    private val chat: ChatEngine,
    private val executor: ActionExecutor,
    private val dao: AvniDao,
    private val settings: SettingsStore
) {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private val _transcript = MutableStateFlow("")
    val transcript: StateFlow<String> = _transcript.asStateFlow()
    val avatarState: StateFlow<AvatarState> = tts.state
    val viseme: StateFlow<String> = tts.viseme

    @Volatile var busy = false
        private set

    fun startWakeWord() {
        scope.launch {
            if (!settings.wakeEnabled.first()) return@launch
            stt.startWakeWord(settings.wakeSensitivity.first()) {
                scope.launch { runOnce() }
            }
        }
    }

    fun stopWakeWord() = stt.stopAll()

    /** One full turn, triggered by tap or wake word. */
    fun runOnce() {
        if (busy) return
        scope.launch {
            busy = true
            try {
                tts.setListening()
                val lang = settings.langLock.first()
                val heard = stt.listenOnce(if (lang == "en") "en" else "hi")
                _transcript.value = heard
                if (heard.isBlank()) {
                    tts.speak("Kuch suna nahi, phir se bolo.")
                    return@launch
                }
                handleText(heard)
            } finally {
                busy = false
                tts.setIdle()
                startWakeWord()
            }
        }
    }

    /** Text path (typed chat) — same brain, no mic. */
    fun handleTextInput(text: String) {
        scope.launch { handleText(text) }
    }

    private suspend fun handleText(text: String) {
        dao.insertChat(ChatMessage(role = "user", text = text, lang = com.avni.ai.core.Language.detect(text)))
        val history = dao.recentChats(12).reversed()
            .map { it.role to it.text }
        tts.setThinking()
        val result = chat.respond(text, history)
        // Dangerous actions need a spoken confirmation first.
        if (result.action in setOf("call", "sms") && !executor.isConfirmed(result)) {
            tts.speak("${result.reply} Confirm karne ke liye 'haan' bolo, cancel ke liye 'nahi'.", emotion = result.emotion)
            val answer = stt.listenOnce("hi", 10_000).lowercase()
            if (!(answer.contains("haan") || answer.contains("yes") || answer.contains("ha"))) {
                tts.speak("Theek hai, cancel kar diya.")
                return
            }
            executor.markConfirmed(result)
        }
        val outcome = executor.execute(result)
        val reply = outcome.ifBlank { result.reply }
        dao.insertChat(ChatMessage(role = "avni", text = reply,
            lang = com.avni.ai.core.Language.detect(reply), emotion = result.emotion))
        tts.speak(reply, emotion = result.emotion)
    }
}
