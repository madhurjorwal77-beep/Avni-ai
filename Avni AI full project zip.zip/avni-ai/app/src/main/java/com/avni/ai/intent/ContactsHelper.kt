package com.avni.ai.intent

import android.content.Context
import android.provider.ContactsContract
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject
import javax.inject.Singleton
import kotlin.math.min

data class Contact(val name: String, val phone: String)

/** Fuzzy contact matching (Hindi/English names) via normalized Levenshtein. */
@Singleton
class ContactsHelper @Inject constructor(
    @ApplicationContext private val ctx: Context
) {
    fun find(query: String): Contact? {
        val q = normalize(query)
        var best: Contact? = null
        var bestScore = Int.MAX_VALUE
        ctx.contentResolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            arrayOf(
                ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                ContactsContract.CommonDataKinds.Phone.NUMBER
            ),
            null, null, null
        )?.use { c ->
            val ni = c.getColumnIndex(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME)
            val pi = c.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER)
            while (c.moveToNext()) {
                val name = c.getString(ni) ?: continue
                val phone = c.getString(pi) ?: continue
                val score = distance(q, normalize(name))
                // Prefix / substring matches win over pure distance.
                val adjusted = when {
                    normalize(name) == q -> 0
                    normalize(name).startsWith(q) -> 1
                    normalize(name).contains(q) -> 2
                    else -> score + 3
                }
                if (adjusted < bestScore) {
                    bestScore = adjusted
                    best = Contact(name, phone)
                }
            }
        }
        // Reject weak matches so Avni never calls the wrong person.
        return if (bestScore <= min(3, q.length / 2 + 1)) best else null
    }

    private fun normalize(s: String) =
        s.lowercase().replace(Regex("[^a-z0-9\\u0900-\\u097F]"), "")

    private fun distance(a: String, b: String): Int {
        val d = Array(a.length + 1) { IntArray(b.length + 1) }
        for (i in 0..a.length) d[i][0] = i
        for (j in 0..b.length) d[0][j] = j
        for (i in 1..a.length) for (j in 1..b.length) {
            d[i][j] = min(
                min(d[i - 1][j] + 1, d[i][j - 1] + 1),
                d[i - 1][j - 1] + if (a[i - 1] == b[j - 1]) 0 else 1
            )
        }
        return d[a.length][b.length]
    }
}
