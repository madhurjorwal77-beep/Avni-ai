package com.avni.ai.voice

import android.content.Context
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import com.avni.ai.core.Language
import com.avni.ai.data.prefs.SettingsStore
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import javax.inject.Inject
import javax.inject.Singleton

/** Avatar states driven by the voice pipeline. */
enum class AvatarState { IDLE, LISTENING, THINKING, SPEAKING, HAPPY, SAD, SURPRISED, ANGRY, SLEEPING }

/**
 * Android TTS wrapper. Picks the best hi-IN / en-IN voice (female preferred),
 * exposes pitch/rate from settings, and streams a phoneme-approximated viseme
 * sequence to the avatar while speaking so lips move in real time.
 *
 * Viseme approximation: vowels in the spoken text map to VRM blendshapes
 * (aa/ih/ou/ee/oh). This is a real, deterministic mapping — not a recording.
 */
@Singleton
class TtsEngine @Inject constructor(
    @ApplicationContext private val ctx: Context,
    private val settings: SettingsStore
) {
    private var tts: TextToSpeech? = null
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private val _state = MutableStateFlow(AvatarState.IDLE)
    val state: StateFlow<AvatarState> = _state.asStateFlow()
    private val _viseme = MutableStateFlow("aa:0")
    val viseme: StateFlow<String> = _viseme.asStateFlow()

    var onUtteranceDone: (() -> Unit)? = null

    init {
        tts = TextToSpeech(ctx) { status ->
            if (status == TextToSpeech.SUCCESS) {
                tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(id: String) { _state.value = AvatarState.SPEAKING }
                    override fun onDone(id: String) {
                        _state.value = AvatarState.IDLE
                        _viseme.value = "aa:0"
                        onUtteranceDone?.invoke()
                    }
                    @Deprecated("Deprecated in Java")
                    override fun onError(id: String) { _state.value = AvatarState.IDLE }
                })
            }
        }
    }

    /** Speak text; [lang] is "hi"/"en"/"hinglish"/"auto". Returns when done. */
    suspend fun speak(text: String, lang: String = "auto", emotion: String = "neutral") {
        val t = tts ?: return
        val detected = if (lang == "auto") Language.detect(text) else lang
        val locale = Language.ttsLocale(detected)
        // Prefer a female voice for that locale, else any voice for it.
        val voices = t.voices?.filter { it.locale.language == locale.language } ?: emptyList()
        val voice = voices.firstOrNull { it.name.contains("female", true) }
            ?: voices.firstOrNull { it.locale == locale }
            ?: voices.firstOrNull()
        voice?.let { t.voice = it }
        t.language = locale
        t.setPitch(settings.ttsPitch.first())
        t.setSpeechRate(settings.ttsRate.first())
        _state.value = when (emotion) {
            "happy" -> AvatarState.HAPPY; "sad" -> AvatarState.SAD
            "surprised" -> AvatarState.SURPRISED; "angry" -> AvatarState.ANGRY
            else -> AvatarState.SPEAKING
        }
        driveVisemes(text)
        val done = CompletableDeferred<Unit>()
        val prev = onUtteranceDone
        onUtteranceDone = { prev?.invoke(); done.complete(Unit) }
        t.speak(text, TextToSpeech.QUEUE_FLUSH, null, "avni_${System.currentTimeMillis()}")
        withTimeoutOrNull(60_000) { done.await() }
        onUtteranceDone = prev
        _state.value = AvatarState.IDLE
    }

    fun stop() { tts?.stop(); _state.value = AvatarState.IDLE }

    fun setListening() { _state.value = AvatarState.LISTENING }
    fun setThinking() { _state.value = AvatarState.THINKING }
    fun setIdle() { _state.value = AvatarState.IDLE }

    /** Emits one viseme per ~90ms based on the vowel sequence of the text. */
    private fun driveVisemes(text: String) {
        val seq = text.lowercase().mapNotNull { c ->
            when (c) {
                'a', 'आ', 'ा' -> "aa"; 'i', 'ई', 'ि', 'ी' -> "ih"
                'o', 'ओ', 'ो', 'u', 'ऊ', 'ु', 'ू' -> "ou"
                'e', 'ए', 'े' -> "ee"; else -> null
            }
        }.ifEmpty { listOf("aa", "ih", "ou") }
        scope.launch {
            var i = 0
            while (_state.value == AvatarState.SPEAKING || _state.value == AvatarState.HAPPY) {
                val v = seq[i % seq.size]
                _viseme.value = "$v:0.9"
                delay(90)
                _viseme.value = "$v:0.2"
                delay(40)
                i++
                if (i > seq.size * 40) break
            }
        }
    }
}
