package com.avni.ai.service

import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.*
import android.os.Bundle
import android.service.quicksettings.Tile
import android.service.quicksettings.TileService
import android.service.voice.VoiceInteractionService
import android.widget.RemoteViews
import com.avni.ai.R
import com.avni.ai.data.prefs.SettingsStore
import com.avni.ai.ui.MainActivity
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.first
import javax.inject.Inject

/** Boot autostart — only if the user enabled it in Settings. */
@AndroidEntryPoint
class BootReceiver : BroadcastReceiver() {
    @Inject lateinit var settings: SettingsStore
    override fun onReceive(ctx: Context, intent: Intent) {
        if (intent.action != Intent.ACTION_BOOT_COMPLETED) return
        CoroutineScope(Dispatchers.IO).launch {
            if (settings.bootStart.first()) AvniVoiceService.start(ctx)
        }
    }
}

/** Quick Settings tile: tap toggles the voice service. */
@AndroidEntryPoint
class AvniTileService : TileService() {
    @Inject lateinit var settings: SettingsStore
    override fun onClick() {
        super.onClick()
        val active = qsTile.state == Tile.STATE_ACTIVE
        if (active) AvniVoiceService.stop(this) else AvniVoiceService.start(this)
        qsTile.state = if (active) Tile.STATE_INACTIVE else Tile.STATE_ACTIVE
        qsTile.updateTile()
    }
    override fun onStartListening() {
        super.onStartListening()
        // State is best-effort; the service notification is the source of truth.
        qsTile.state = Tile.STATE_INACTIVE
        qsTile.updateTile()
    }
}

/** Home widget: tap opens Avni. */
class AvniWidgetProvider : AppWidgetProvider() {
    override fun onUpdate(
        ctx: Context, manager: AppWidgetManager, ids: IntArray
    ) {
        for (id in ids) {
            val views = RemoteViews(ctx.packageName, R.layout.widget_avni)
            val intent = Intent(ctx, MainActivity::class.java)
            views.setOnClickPendingIntent(R.id.widget_mic,
                PendingIntent.getActivity(ctx, 0, intent,
                    PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT))
            manager.updateAppWidget(id, views)
        }
    }
}

/**
 * Default-assistant registration. Long-press home / assistant gesture
 * opens Avni's main screen: the session is a thin bridge that hands off
 * to MainActivity (the real assistant surface) instead of pretending to
 * be a full overlay session UI.
 */
@AndroidEntryPoint
class AvniVoiceInteractionService : VoiceInteractionService()

class AvniSessionService : android.service.voice.VoiceInteractionSessionService() {
    override fun onNewSession(bundle: Bundle?): android.service.voice.VoiceInteractionSession {
        return AvniSession(this)
    }
}

class AvniSession(
    ctx: android.service.voice.VoiceInteractionSessionService
) : android.service.voice.VoiceInteractionSession(ctx) {
    override fun onCreateContentView(): android.view.View {
        return android.widget.TextView(context).apply {
            text = "Avni khul rahi hai…"
            setTextColor(0xFFE8F6FF.toInt())
        }
    }
    override fun onHandleAssist(data: Bundle?, structuredData: Bundle?, content: Bundle?) {
        super.onHandleAssist(data, structuredData, content)
        context.startActivity(Intent(context, MainActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        hide()
    }
}
