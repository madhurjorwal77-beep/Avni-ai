package com.avni.ai.llm

import java.text.SimpleDateFormat
import java.util.*

/**
 * Fully offline rule engine. Handles commands, greetings, memory phrases
 * and small talk WITHOUT any model, so Avni always works — even before the
 * GGUF model is downloaded. Hinglish + English + Devanagari Hindi.
 */
class RuleChatEngine : ChatEngine {
    override suspend fun respond(userText: String, history: List<Pair<String, String>>): AvniAction {
        val t = userText.trim()
        val low = t.lowercase(Locale.ROOT)
        fun act(a: String, reply: String, vararg p: Pair<String, String>) =
            AvniAction(a, mapOf(*p), reply)

        // --- Memory: "yaad rakho ki mera naam X hai" / "remember that ..." ---
        Regex("(?:yaad rakho(?: ki)?|remember that)\\s+(.+)", RegexOption.IGNORE_CASE)
            .find(t)?.let { m ->
                return act("remember", "Ho gaya, yaad rakh liya. [happy]", "fact" to m.groupValues[1])
            }
        Regex("(?:mera naam|my name is)\\s+([A-Za-z]+)", RegexOption.IGNORE_CASE)
            .find(t)?.let { m ->
                return act("remember", "Namaste, ${m.groupValues[1]}! Naam yaad rakh liya. [happy]",
                    "name" to m.groupValues[1])
            }

        // --- Routines ---
        if (low.contains("good morning") || low.contains("suprabhat") || low.contains("shubh prabhat"))
            return act("routine", "Good morning! Aaj ka briefing la rahi hun. [happy]", "name" to "good_morning")
        if (low.contains("good night") || low.contains("shubh ratri"))
            return act("routine", "Shubh ratri! Kal subah milte hain. [happy]", "name" to "good_night")

        // --- Torch ---
        if (low.contains("torch") || low.contains("flashlight") || low.contains("flash")) {
            val on = !(low.contains("band") || low.contains("off"))
            return act("torch", if (on) "Torch on kar diya." else "Torch band kar diya.",
                "on" to on.toString())
        }
        // --- Volume / brightness / DND ---
        Regex("(volume|awaaz)\\s*(?:ko)?\\s*(\\d{1,3})").find(low)?.let {
            return act("volume", "Volume ${it.groupValues[2]} par set kar diya.",
                "level" to it.groupValues[2])
        }
        if (low.contains("dnd") || low.contains("do not disturb") || low.contains("pareshan mat karo"))
            return act("dnd", "Do Not Disturb on kar diya.", "on" to "true")
        if (low.contains("brightness") || low.contains("chamak")) {
            Regex("(\\d{1,3})").find(low)?.let {
                return act("brightness", "Brightness ${it.groupValues[1]} par set kar diya.",
                    "level" to it.groupValues[1])
            }
        }
        // --- Battery ---
        if (low.contains("battery") || low.contains("charge"))
            return act("battery", "Battery status check kar rahi hun.")
        // --- Time / date ---
        if (low.contains("time") || low.contains("samay") || low.contains("baje")) {
            val now = SimpleDateFormat("h:mm a", Locale("en", "IN")).format(Date())
            return act("chat", "Abhi $now baj rahe hain.")
        }
        if (low.contains("date") || low.contains("tarikh") || low.contains("din")) {
            val now = SimpleDateFormat("EEEE, d MMMM yyyy", Locale("en", "IN")).format(Date())
            return act("chat", "Aaj $now hai.")
        }
        // --- Call / SMS ---
        Regex("(?:call karo|call|phone karo)\\s+(?:ko\\s+)?(.+)", RegexOption.IGNORE_CASE)
            .find(t)?.let { m ->
                return act("call", " ${m.groupValues[1]} ko call karne se pehle confirm kar rahi hun.",
                    "name" to m.groupValues[1].trim())
            }
        Regex("(?:message|msg|sms|bhejo)\\s+(?:ko\\s+)?(.+?)(?:\\s+ko)?\\s+(.+)", RegexOption.IGNORE_CASE)
            .find(t)?.let { m ->
                return act("sms", "${m.groupValues[1]} ko message bhejne se pehle confirm kar rahi hun.",
                    "name" to m.groupValues[1].trim(), "text" to m.groupValues[2].trim())
            }
        // --- Open app ---
        Regex("(?:kholo|open)\\s+(.+)", RegexOption.IGNORE_CASE).find(t)?.let { m ->
            return act("open_app", "${m.groupValues[1]} khol rahi hun.", "app" to m.groupValues[1].trim())
        }
        // --- Maps ---
        Regex("(?:maps|navigation|le chalo|jaana hai)\\s+(?:to\\s+)?(.+)", RegexOption.IGNORE_CASE)
            .find(t)?.let { m ->
                return act("maps", "${m.groupValues[1]} ka navigation khol rahi hun.", "place" to m.groupValues[1].trim())
            }
        // --- Web search ---
        Regex("(?:search karo|google karo|dhoondo)\\s+(.+)", RegexOption.IGNORE_CASE).find(t)?.let { m ->
            return act("web_search", "${m.groupValues[1]} search kar rahi hun.", "query" to m.groupValues[1].trim())
        }
        // --- Camera / screenshot ---
        if (low.contains("camera") || low.contains("photo"))
            return act("camera", "Camera khol rahi hun.")
        if (low.contains("screenshot"))
            return act("screenshot", "Screenshot le rahi hun.")
        // --- Screen read / tap ---
        if (low.contains("screen") && (low.contains("padho") || low.contains("read")))
            return act("screen_read", "Screen padh rahi hun.")
        Regex("(?:tap karo|dabao|click karo)\\s+(.+)", RegexOption.IGNORE_CASE).find(t)?.let { m ->
            return act("tap_text", "${m.groupValues[1]} par tap kar rahi hun.", "text" to m.groupValues[1].trim())
        }
        // --- Greetings / small talk ---
        return when {
            low.contains("hello") || low.contains("hi") || low.contains("namaste") ->
                act("chat", "Namaste! Main Avni hun. Kya kar sakti hun tumhare liye? [happy]")
            low.contains("kaise ho") || low.contains("how are you") ->
                act("chat", "Main bilkul theek hun, aur tum? Bolo, kya kaam hai? [happy]")
            low.contains("joke") || low.contains("hasao") ->
                act("chat", "Phone ne mujhse kaha — main tumhare bina adhura hun. Kyunki tum hi mera charger ho! [happy]")
            low.contains("tum kaun") || low.contains("who are you") || low.contains("tumhara naam") ->
                act("chat", "Main Avni hun — tumhari apni voice assistant, jo poori tarah tumhare phone par chalti hai, bina internet ke.")
            low.contains("dhanyavad") || low.contains("thank") ->
                act("chat", "Koi baat nahi! Hamesha tumhari seva mein. [happy]")
            low.contains("bye") || low.contains("alvida") ->
                act("chat", "Alvida! Jab zaroorat ho, bas 'Hey Avni' bolna. [happy]")
            else -> act("chat", "Samajh gayi — par iska seedha jawab mere paas abhi nahi hai. " +
                "Tum 'torch on karo', 'Rahul ko call karo' ya 'good morning' try kar sakte ho.")
        }
    }
}
