package com.avni.ai.ui.screens

import android.content.Intent
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.avni.ai.data.prefs.SettingsStore
import com.avni.ai.llm.DownloadState
import com.avni.ai.llm.ModelManager
import com.avni.ai.ui.MainViewModel
import dagger.hilt.android.EntryPointAccessors
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

@Composable
fun ModelScreen(vm: MainViewModel, nav: NavController) {
    val ctx = LocalContext.current
    val modelManager = remember {
        EntryPointAccessors.fromApplication(ctx.applicationContext, ModelEntryPoint::class.java).modelManager()
    }
    val state by modelManager.state.collectAsState()
    var engine by remember { mutableStateOf("llama") }
    val scope = rememberCoroutineScope()
    val pickGguf = rememberLauncherForActivityResult(
        ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) scope.launch {
            val r = modelManager.importFromUri(uri)
            if (r.isFailure) {
                // Show via snackbar-less simple state: reuse DownloadState.Error
            }
        }
    }
    Column(Modifier.fillMaxSize().padding(16.dp).verticalScroll(rememberScrollState())) {
        BackBar(nav, "Model Manager")
        Text("On-device LLM: Qwen2.5 1.5B Instruct Q4_K_M (~1 GB). " +
            "Download resumable hai — ruk jaye to dobara shuru karo, wahi se chalega. " +
            "Ya apni local .gguf file import karo. Model na ho to bhi Avni " +
            "rule engine se commands aur baat-cheet chala legi.",
            Modifier.padding(vertical = 8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("llama" to "llama.cpp", "mediapipe" to "MediaPipe", "rules" to "Rules only").forEach { (id, label) ->
                FilterChip(selected = engine == id, onClick = {
                    engine = id
                    scope.launch { vm.settings.set(SettingsStore.MODEL_ENGINE, id) }
                }, label = { Text(label) })
            }
        }
        Spacer(Modifier.height(12.dp))
        Button(onClick = {
            modelManager.download(
                "https://huggingface.co/Qwen/Qwen2.5-1.5B-Instruct-GGUF/resolve/main/qwen2.5-1.5b-instruct-q4_k_m.gguf")
        }, modifier = Modifier.fillMaxWidth()) { Text("Download model (HF)") }
        OutlinedButton(onClick = { pickGguf.launch("*/*") },
            modifier = Modifier.fillMaxWidth().padding(top = 8.dp)) {
            Text("Local .gguf import karo")
        }
        OutlinedButton(onClick = { modelManager.cancel() },
            modifier = Modifier.fillMaxWidth().padding(top = 8.dp)) {
            Text("Pause / Cancel")
        }
        Spacer(Modifier.height(16.dp))
        when (val s = state) {
            is DownloadState.Progress -> {
                val pct = if (s.total > 0) (s.downloaded * 100 / s.total).toInt() else 0
                Text("Download: $pct% (${s.downloaded / 1_048_576} / ${s.total / 1_048_576} MB)")
                LinearProgressIndicator(progress = { pct / 100f }, modifier = Modifier.fillMaxWidth())
            }
            is DownloadState.Done -> Text("✓ Model ready: ${s.path}")
            is DownloadState.Error -> Text("Note: ${s.msg}")
            DownloadState.Idle -> Text("Abhi koi download nahi chal raha.")
        }
    }
}

@dagger.hilt.EntryPoint
@dagger.hilt.InstallIn(dagger.hilt.components.SingletonComponent::class)
interface ModelEntryPoint {
    fun modelManager(): ModelManager
}

@Composable
fun SettingsScreen(vm: MainViewModel, nav: NavController) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var name by remember { mutableStateOf("") }
    var prompt by remember { mutableStateOf("") }
    var pitch by remember { mutableStateOf(1.05f) }
    var rate by remember { mutableStateOf(1.0f) }
    var wake by remember { mutableStateOf(true) }
    var lowRam by remember { mutableStateOf(false) }
    var lowPower by remember { mutableStateOf(false) }
    var overlay by remember { mutableStateOf(false) }
    var boot by remember { mutableStateOf(false) }
    var banking by remember { mutableStateOf(false) }
    var lang by remember { mutableStateOf("auto") }
    var showDelete by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        name = vm.settings.userName.first()
        prompt = vm.settings.systemPrompt.first()
        pitch = vm.settings.ttsPitch.first()
        rate = vm.settings.ttsRate.first()
        wake = vm.settings.wakeEnabled.first()
        lowRam = vm.settings.lowRam.first()
        lowPower = vm.settings.lowPowerAvatar.first()
        overlay = vm.settings.overlayEnabled.first()
        boot = vm.settings.bootStart.first()
        banking = vm.settings.bankingAllowed.first()
        lang = vm.settings.langLock.first()
    }

    fun save() = scope.launch {
        vm.settings.set(SettingsStore.USER_NAME, name)
        vm.settings.set(SettingsStore.SYSTEM_PROMPT, prompt)
        vm.settings.set(SettingsStore.TTS_PITCH, pitch)
        vm.settings.set(SettingsStore.TTS_RATE, rate)
        vm.settings.set(SettingsStore.WAKE_ENABLED, wake)
        vm.settings.set(SettingsStore.LOW_RAM, lowRam)
        vm.settings.set(SettingsStore.LOW_POWER_AVATAR, lowPower)
        vm.settings.set(SettingsStore.OVERLAY_ENABLED, overlay)
        vm.settings.set(SettingsStore.BOOT_START, boot)
        vm.settings.set(SettingsStore.BANKING_ALLOWED, banking)
        vm.settings.set(SettingsStore.LANG_LOCK, lang)
        if (overlay) {
            if (!Settings.canDrawOverlays(ctx)) {
                ctx.startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION))
            } else {
                ctx.startService(Intent(ctx, com.avni.ai.service.AvniOverlayService::class.java))
            }
        }
    }

    Column(Modifier.fillMaxSize().padding(16.dp).verticalScroll(rememberScrollState())) {
        BackBar(nav, "Settings")
        OutlinedTextField(name, { name = it }, Modifier.fillMaxWidth(), label = { Text("Tumhara naam") })
        OutlinedTextField(prompt, { prompt = it }, Modifier.fillMaxWidth().padding(top = 8.dp),
            label = { Text("Personality / System prompt") }, minLines = 3)
        Text("Voice pitch: ${"%.2f".format(pitch)}", Modifier.padding(top = 12.dp))
        Slider(pitch, { pitch = it }, valueRange = 0.7f..1.4f)
        Text("Voice speed: ${"%.2f".format(rate)}")
        Slider(rate, { rate = it }, valueRange = 0.7f..1.5f)
        Text("Language", Modifier.padding(top = 8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("auto" to "Auto", "hi" to "Hindi", "en" to "English").forEach { (id, label) ->
                FilterChip(selected = lang == id, onClick = { lang = id }, label = { Text(label) })
            }
        }
        SwitchRow("Wake word 'Hey Avni'", wake) { wake = it }
        SwitchRow("Low-RAM mode (chhota context)", lowRam) { lowRam = it }
        SwitchRow("Low-power avatar (30fps)", lowPower) { lowPower = it }
        SwitchRow("Overlay bubble", overlay) { overlay = it }
        SwitchRow("Boot par auto-start", boot) { boot = it }
        SwitchRow("Banking/UPI apps allow (risk samajh kar)", banking) { banking = it }
        Button(onClick = { save() }, Modifier.fillMaxWidth().padding(top = 12.dp)) {
            Text("Save settings")
        }
        OutlinedButton(onClick = { showDelete = true },
            Modifier.fillMaxWidth().padding(top = 8.dp)) {
            Text("Delete all data (chat, memory, logs)")
        }
        if (showDelete) {
            AlertDialog(
                onDismissRequest = { showDelete = false },
                title = { Text("Pakka delete karna hai?") },
                text = { Text("Saari chats, yaadein, action log aur settings mit jayenge. Ye wapas nahi aayega.") },
                confirmButton = {
                    TextButton(onClick = { vm.clearAllData(); showDelete = false }) { Text("Delete") }
                },
                dismissButton = {
                    TextButton(onClick = { showDelete = false }) { Text("Cancel") }
                }
            )
        }
    }
}

@Composable
private fun SwitchRow(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, Modifier.weight(1f).padding(top = 10.dp))
        Switch(checked = checked, onCheckedChange = onChange)
    }
}
