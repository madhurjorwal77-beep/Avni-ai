package com.avni.ai.data.db

import androidx.room.*

@Entity(tableName = "chats")
data class ChatMessage(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val role: String,            // "user" | "avni"
    val text: String,
    val lang: String,            // "hi" | "en" | "hinglish"
    val emotion: String = "neutral",
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "facts")
data class MemoryFact(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val key: String,             // e.g. "user_name", "likes", "custom:..."
    val value: String,
    val updatedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "actions")
data class ActionLogEntry(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val action: String,
    val detail: String,
    val success: Boolean,
    val undoable: Boolean = false,
    val undoData: String? = null,
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "routines")
data class Routine(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val trigger: String,         // phrase, lowercased, e.g. "good morning"
    val stepsJson: String,       // JSON array of {action, params}
    val enabled: Boolean = true
)

@Dao
interface AvniDao {
    @Insert suspend fun insertChat(m: ChatMessage)
    @Query("SELECT * FROM chats ORDER BY timestamp DESC LIMIT :n")
    suspend fun recentChats(n: Int): List<ChatMessage>
    @Query("DELETE FROM chats") suspend fun clearChats()

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertFact(f: MemoryFact)
    @Query("SELECT * FROM facts WHERE `key` = :key LIMIT 1")
    suspend fun fact(key: String): MemoryFact?
    @Query("SELECT * FROM facts ORDER BY updatedAt DESC")
    suspend fun allFacts(): List<MemoryFact>
    @Query("DELETE FROM facts WHERE `key` = :key") suspend fun deleteFact(key: String)
    @Query("DELETE FROM facts") suspend fun clearFacts()

    @Insert suspend fun insertAction(a: ActionLogEntry)
    @Query("SELECT * FROM actions ORDER BY timestamp DESC LIMIT 100")
    suspend fun recentActions(): List<ActionLogEntry>
    @Query("DELETE FROM actions") suspend fun clearActions()

    @Insert suspend fun insertRoutine(r: Routine)
    @Query("SELECT * FROM routines WHERE enabled = 1")
    suspend fun enabledRoutines(): List<Routine>
    @Query("SELECT * FROM routines") suspend fun allRoutines(): List<Routine>
    @Query("DELETE FROM routines WHERE id = :id") suspend fun deleteRoutine(id: Long)
}

@Database(
    entities = [ChatMessage::class, MemoryFact::class, ActionLogEntry::class, Routine::class],
    version = 1, exportSchema = false
)
abstract class AvniDatabase : RoomDatabase() {
    abstract fun dao(): AvniDao
}
