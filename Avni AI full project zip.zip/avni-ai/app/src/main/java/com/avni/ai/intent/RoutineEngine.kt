package com.avni.ai.intent

import android.content.Context
import com.avni.ai.data.db.AvniDao
import com.avni.ai.llm.AvniAction
import dagger.hilt.android.qualifiers.ApplicationContext
import org.json.JSONArray
import javax.inject.Inject
import javax.inject.Provider
import javax.inject.Singleton

/**
 * Routines: a trigger phrase runs a chain of actions. Built-ins:
 * "good_morning" (battery + calendar + summary), "good_night".
 * Users add their own macros in the Routines screen (stored in Room).
 * No news/weather network calls — the summary uses cached/local data only,
 * and says so honestly when nothing is cached.
 */
@Singleton
class RoutineEngine @Inject constructor(
    @ApplicationContext private val ctx: Context,
    private val dao: AvniDao,
    private val executorProvider: Provider<ActionExecutor>
) {
    private val executor: ActionExecutor get() = executorProvider.get()
    suspend fun run(name: String): String {
        return when (name) {
            "good_morning" -> {
                val parts = mutableListOf<String>()
                parts += executor.execute(AvniAction("battery", emptyMap(), ""))
                val cal = executor.execute(AvniAction("calendar", mapOf("scope" to "today"), ""))
                parts += cal
                val name = dao.fact("user_name")?.value ?: ""
                val greet = if (name.isNotBlank()) "Good morning, $name!" else "Good morning!"
                "$greet ${parts.joinToString(" ")} Aaj ka din achha rahe."
            }
            "good_night" -> {
                executor.execute(AvniAction("dnd", mapOf("on" to "true"), ""))
                "Shubh ratri. DND on kar diya hai, kal subah milte hain."
            }
            else -> {
                // User macro: match trigger in Room.
                val routine = dao.enabledRoutines().firstOrNull { it.trigger == name }
                    ?: return "Woh routine nahi mili."
                val steps = JSONArray(routine.stepsJson)
                val out = mutableListOf<String>()
                for (i in 0 until steps.length()) {
                    val s = steps.getJSONObject(i)
                    val params = mutableMapOf<String, String>()
                    val p = s.optJSONObject("params")
                    if (p != null) for (k in p.keys()) params[k] = p.optString(k)
                    out += executor.execute(AvniAction(s.optString("action"), params, ""))
                }
                out.filter { it.isNotBlank() }.joinToString(" ").ifBlank { "Routine poori ho gayi." }
            }
        }
    }
}
