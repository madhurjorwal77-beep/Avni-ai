package com.avni.ai.ui

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.core.content.ContextCompat
import androidx.navigation.compose.*
import com.avni.ai.data.prefs.SettingsStore
import com.avni.ai.service.AvniVoiceService
import com.avni.ai.ui.screens.*
import com.avni.ai.ui.theme.AvniTheme
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

@AndroidEntryPoint
class MainActivity : ComponentActivity() {
    private val vm: MainViewModel by viewModels()

    private val micPermission = registerForActivityResult(
        ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) AvniVoiceService.start(this)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
            != PackageManager.PERMISSION_GRANTED) {
            micPermission.launch(Manifest.permission.RECORD_AUDIO)
        } else AvniVoiceService.start(this)

        setContent {
            AvniTheme {
                val nav = rememberNavController()
                val scope = rememberCoroutineScope()
                var start by remember { mutableStateOf("main") }
                LaunchedEffect(Unit) {
                    if (!vm.settings.onboarded.first()) start = "onboarding"
                }
                NavHost(nav, startDestination = start) {
                    composable("onboarding") {
                        OnboardingScreen(
                            onDone = {
                                scope.launch {
                                    vm.settings.set(SettingsStore.ONBOARDED, true)
                                    nav.navigate("main") { popUpTo("onboarding") { inclusive = true } }
                                }
                            },
                            onOpenSettings = { openSystemSettings(it) }
                        )
                    }
                    composable("main") { MainScreen(vm, nav) }
                    composable("chat") { ChatScreen(vm, nav) }
                    composable("memory") { MemoryScreen(vm, nav) }
                    composable("routines") { RoutinesScreen(vm, nav) }
                    composable("actions") { ActionLogScreen(vm, nav) }
                    composable("model") { ModelScreen(vm, nav) }
                    composable("settings") { SettingsScreen(vm, nav) }
                    composable("about") { AboutScreen(nav) }
                }
            }
        }
    }

    private fun openSystemSettings(kind: String) {
        val intent = when (kind) {
            "accessibility" -> Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)
            "notification" -> Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)
            "overlay" -> Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION)
            else -> Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS)
        }
        startActivity(intent)
    }
}
