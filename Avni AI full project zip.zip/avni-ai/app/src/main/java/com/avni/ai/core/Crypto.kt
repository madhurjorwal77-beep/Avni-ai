package com.avni.ai.core

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import java.security.KeyStore
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey

/** SQLCipher key: generated once, stored in AndroidKeyStore, never in code. */
object Crypto {
    private const val ALIAS = "avni_db_key"
    private const val PREFS = "avni_crypto"
    private const val KEY_B64 = "db_key_b64"

    fun dbKey(ctx: Context): ByteArray {
        val prefs = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        prefs.getString(KEY_B64, null)?.let {
            return android.util.Base64.decode(it, android.util.Base64.DEFAULT)
        }
        // Generate a random 256-bit key, wrap it with a KeyStore key for storage.
        val raw = ByteArray(32).also { java.security.SecureRandom().nextBytes(it) }
        val ksKey = getOrCreateKeyStoreKey()
        val cipher = javax.crypto.Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(javax.crypto.Cipher.ENCRYPT_MODE, ksKey)
        val iv = cipher.iv
        val sealed = cipher.doFinal(raw)
        val combined = iv + sealed
        prefs.edit().putString(KEY_B64,
            android.util.Base64.encodeToString(combined, android.util.Base64.DEFAULT)).apply()
        return raw
    }

    private fun getOrCreateKeyStoreKey(): SecretKey {
        val ks = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        ks.getKey(ALIAS, null)?.let { return it as SecretKey }
        val gen = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        gen.init(KeyGenParameterSpec.Builder(ALIAS,
            KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
            .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
            .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
            .build())
        return gen.generateKey()
    }
}
