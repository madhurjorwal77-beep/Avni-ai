package com.avni.ai.ui.screens

import android.webkit.WebView
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.navigation.NavController
import com.avni.ai.avatar.AvatarBridge
import com.avni.ai.avatar.createAvatarWebView
import com.avni.ai.ui.MainViewModel
import com.avni.ai.voice.AvatarState

@Composable
fun MainScreen(vm: MainViewModel, nav: NavController) {
    val ctx = LocalContext.current
    var bridge by remember { mutableStateOf<AvatarBridge?>(null) }
    val state by vm.avatarState.collectAsState()
    val viseme by vm.viseme.collectAsState()
    val transcript by vm.transcript.collectAsState()
    var typed by remember { mutableStateOf("") }

    // Forward pipeline state -> avatar JS
    LaunchedEffect(state) { bridge?.setState(state) }
    LaunchedEffect(viseme) { bridge?.setViseme(viseme) }
    LaunchedEffect(state) {
        if (state == AvatarState.HAPPY) bridge?.gesture("wave")
    }

    Column(Modifier.fillMaxSize()) {
        Box(Modifier.weight(1f).fillMaxWidth()) {
            AndroidView(
                factory = { createAvatarWebView(ctx) { bridge = it } },
                modifier = Modifier.fillMaxSize(),
                onRelease = { it.destroy() }
            )
            // Camera mode chips
            Row(Modifier.align(Alignment.TopCenter).padding(8.dp)) {
                listOf("full" to "Full", "bust" to "Bust", "closeup" to "Close-up").forEach { (mode, label) ->
                    Button(
                        onClick = { bridge?.setCamera(mode) },
                        modifier = Modifier.padding(2.dp),
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 2.dp)
                    ) { Text(label) }
                }
            }
        }
        Text(
            text = when (state) {
                AvatarState.LISTENING -> "Sun rahi hun…"
                AvatarState.THINKING -> "Soch rahi hun…"
                AvatarState.SPEAKING -> "Bol rahi hun…"
                AvatarState.SLEEPING -> "So rahi hai…"
                else -> "Hey Avni bolo, ya mic dabao"
            },
            modifier = Modifier.padding(horizontal = 16.dp),
            color = MaterialTheme.colorScheme.primary
        )
        if (transcript.isNotBlank()) {
            Text("Tumne kaha: $transcript",
                Modifier.padding(horizontal = 16.dp, vertical = 4.dp))
        }
        Row(
            Modifier.fillMaxWidth().padding(12.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            OutlinedTextField(
                value = typed, onValueChange = { typed = it },
                modifier = Modifier.weight(1f), placeholder = { Text("Type karke bhi poochho…") },
                singleLine = true
            )
            Button(onClick = {
                if (typed.isNotBlank()) { vm.sendText(typed); typed = "" }
            }) { Text("Bhejo") }
        }
        Button(
            onClick = { vm.talk() },
            modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp)
        ) { Text("🎙️ Baat karo") }
        Row(
            Modifier.fillMaxWidth().padding(12.dp).verticalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            listOf(
                "chat" to "Chat", "memory" to "Memory", "routines" to "Routines",
                "actions" to "Log", "model" to "Model", "settings" to "Settings", "about" to "About"
            ).forEach { (route, label) ->
                OutlinedButton(onClick = { nav.navigate(route) }) { Text(label) }
            }
        }
    }
}
