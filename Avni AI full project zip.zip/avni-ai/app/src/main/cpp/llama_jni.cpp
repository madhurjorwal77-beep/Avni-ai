// Real JNI bridge to llama.cpp (built only when llama.cpp/ is present).
// ChatML prompt -> llama_decode loop with greedy-ish sampling (temp 0.7).
#include <jni.h>
#include <string>
#include <vector>
#include <android/log.h>
#include "llama.h"
#include "common.h"

#define LOG(...) __android_log_print(ANDROID_LOG_INFO, "AvniLlama", __VA_ARGS__)

static llama_model* g_model = nullptr;
static llama_context* g_ctx = nullptr;
static std::string g_last;

extern "C" JNIEXPORT jboolean JNICALL
Java_com_avni_ai_llm_LlamaEngine_nativeInit(JNIEnv* env, jobject, jstring jpath, jint nCtx, jint nThreads) {
    const char* path = env->GetStringUTFChars(jpath, nullptr);
    llama_model_params mp = llama_model_default_params();
    g_model = llama_model_load_from_file(path, mp);
    env->ReleaseStringUTFChars(jpath, path);
    if (!g_model) { LOG("model load failed"); return JNI_FALSE; }
    llama_context_params cp = llama_context_default_params();
    cp.n_ctx = (uint32_t)nCtx;
    cp.n_threads = nThreads;
    cp.n_threads_batch = nThreads;
    g_ctx = llama_new_context_with_model(g_model, cp);
    return g_ctx ? JNI_TRUE : JNI_FALSE;
}

extern "C" JNIEXPORT jstring JNICALL
Java_com_avni_ai_llm_LlamaEngine_nativeComplete(JNIEnv* env, jobject, jstring jprompt, jint maxTokens) {
    if (!g_ctx || !g_model) return env->NewStringUTF("");
    const char* prompt = env->GetStringUTFChars(jprompt, nullptr);
    std::string out;
    llama_kv_cache_clear(g_ctx);
    std::vector<llama_token> tokens = common_tokenize(g_ctx, prompt, true, true);
    llama_batch batch = llama_batch_get_one(tokens.data(), (int)tokens.size());
    if (llama_decode(g_ctx, batch) != 0) { env->ReleaseStringUTFChars(jprompt, prompt); return env->NewStringUTF(""); }
    llama_sampler* sampler = llama_sampler_chain_init(llama_sampler_chain_default_params());
    llama_sampler_chain_add(sampler, llama_sampler_init_temp(0.7f));
    llama_sampler_chain_add(sampler, llama_sampler_init_dist(LLAMA_SAMPLER_SEED_DEFAULT));
    const llama_token eos = llama_token_eos(g_model);
    for (int i = 0; i < maxTokens; i++) {
        llama_token tok = llama_sampler_sample(sampler, g_ctx, -1);
        if (tok == eos) break;
        char buf[64];
        int n = llama_token_to_piece(g_model, tok, buf, sizeof(buf), 0, true);
        if (n < 0) break;
        out.append(buf, (size_t)n);
        llama_batch single = llama_batch_get_one(&tok, 1);
        if (llama_decode(g_ctx, single) != 0) break;
    }
    llama_sampler_free(sampler);
    env->ReleaseStringUTFChars(jprompt, prompt);
    return env->NewStringUTF(out.c_str());
}

extern "C" JNIEXPORT void JNICALL
Java_com_avni_ai_llm_LlamaEngine_nativeFree(JNIEnv*, jobject) {
    if (g_ctx) { llama_free(g_ctx); g_ctx = nullptr; }
    if (g_model) { llama_model_free(g_model); g_model = nullptr; }
}

extern "C" JNIEXPORT jboolean JNICALL
Java_com_avni_ai_llm_LlamaEngine_nativeIsLoaded(JNIEnv*, jobject) {
    return (g_ctx && g_model) ? JNI_TRUE : JNI_FALSE;
}
