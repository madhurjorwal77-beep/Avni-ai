// Stub built only when llama.cpp/ was NOT fetched. Same JNI symbols, but
// every call reports "not available" so Kotlin falls back to the rule engine.
#include <jni.h>

extern "C" JNIEXPORT jboolean JNICALL
Java_com_avni_ai_llm_LlamaEngine_nativeInit(JNIEnv*, jobject, jstring, jint, jint) { return JNI_FALSE; }
extern "C" JNIEXPORT jstring JNICALL
Java_com_avni_ai_llm_LlamaEngine_nativeComplete(JNIEnv* env, jobject, jstring, jint) { return env->NewStringUTF(""); }
extern "C" JNIEXPORT void JNICALL
Java_com_avni_ai_llm_LlamaEngine_nativeFree(JNIEnv*, jobject) {}
extern "C" JNIEXPORT jboolean JNICALL
Java_com_avni_ai_llm_LlamaEngine_nativeIsLoaded(JNIEnv*, jobject) { return JNI_FALSE; }
