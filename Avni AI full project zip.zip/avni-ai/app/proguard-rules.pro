# Keep JNI + Vosk + Room classes
-keep class com.avni.ai.llm.LlamaEngine { *; }
-keep class org.vosk.** { *; }
-keep class androidx.room.** { *; }
-keep class com.google.mediapipe.** { *; }
